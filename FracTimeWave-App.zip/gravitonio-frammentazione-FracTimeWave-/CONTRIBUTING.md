# Contributing to FracTimeWave

Thank you for your interest in contributing to FracTimeWave! This document provides guidelines and information for contributors.

## 🌊 About FracTimeWave

FracTimeWave is an advanced scientific application implementing Danilo Madia's Fractal Graviton Theory (FGT) with multi-dimensional temporal analysis capabilities. Contributions should maintain scientific accuracy while improving usability and functionality.

## 🚀 Getting Started

### Prerequisites
- Python 3.11+
- Node.js 18+
- MongoDB 7.0+
- Git
- Basic understanding of theoretical physics (helpful but not required)

### Development Setup

1. **Fork and Clone**
```bash
git clone https://github.com/your-username/fractimewave.git
cd fractimewave
```

2. **Backend Setup**
```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

3. **Frontend Setup**
```bash
cd frontend
yarn install
```

4. **Database Setup**
```bash
# Start MongoDB locally or use Docker
docker run -d -p 27017:27017 --name mongo mongo:7.0
```

5. **Run Development Servers**
```bash
# Terminal 1: Backend
cd backend && python server.py

# Terminal 2: Frontend
cd frontend && yarn start
```

## 📋 Types of Contributions

### 🔬 Scientific Contributions
- **Mathematical Algorithm Improvements**: Enhance FGT calculations
- **Temporal Analysis**: Improve Sistema_Cronobinario accuracy
- **Gravitonium Optimization**: Refine g_g and m² parameter handling
- **New Physics Models**: Add related theoretical frameworks

### 💻 Technical Contributions
- **Frontend Features**: React components, UI/UX improvements
- **Backend API**: FastAPI endpoints, database optimizations
- **Performance**: Optimization of calculations and visualizations
- **Testing**: Unit tests, integration tests, scientific validation

### 🌍 Localization Contributions
- **New Languages**: Add support beyond current 7 languages
- **Translation Improvements**: Refine scientific terminology
- **Cultural Adaptation**: Ensure scientific concepts are culturally appropriate

### 📚 Documentation
- **Scientific Documentation**: Explain mathematical concepts
- **User Guides**: Tutorials for researchers and educators
- **API Documentation**: Comprehensive endpoint documentation
- **Code Comments**: Explain complex scientific calculations

## 🧪 Scientific Guidelines

### Mathematical Accuracy
- All calculations must maintain scientific precision
- Include unit tests for mathematical functions
- Document formulas using proper LaTeX notation
- Provide references for theoretical foundations

### Key Scientific Principles to Preserve:
1. **Fractal Dimension**: D₁₀,f = 1.7 must remain consistent
2. **Gravitonium Parameters**: g_g ≈ 10³, m² ≈ 10⁸ eV² optimization
3. **Temporal Node Validation**: 27/12/2025 detection accuracy
4. **Binary Encoding**: SHA-256, 64-bit temporal signatures
5. **Multi-dimensional**: 10D+1 spacetime modeling

## 💻 Development Guidelines

### Code Style

**Python (Backend)**
```python
# Use type hints
def calculate_fractal_tensor(r: float, t: np.ndarray) -> tuple[np.ndarray, float]:
    """
    Calculate fractal metric tensor with Gravitonium optimization.
    
    Args:
        r: Spatial scale parameter
        t: Time array for simulation
        
    Returns:
        Tuple of (tensor_values, efficiency_metric)
    """
    pass

# Use scientific notation for clarity
gravitonium_coupling = 1e3  # g_g ≈ 10³
mass_squared = 1e8  # m² ≈ 10⁸ eV²
```

**JavaScript (Frontend)**
```javascript
// Use descriptive variable names for scientific parameters
const fractalDimension = 1.7; // D₁₀,f
const spatialScale = 100; // r parameter

// Document complex calculations
const calculateHarmonicField = (timestamp) => {
  // H₁₀ harmonic field calculation based on FGT theory
  // Reference: Zenodo 16734344
  return harmonicSum;
};
```

### Testing Requirements

**Scientific Validation Tests**
```python
def test_temporal_node_detection():
    """Verify 27/12/2025 is detected as temporal node."""
    result = predict_temporal_node("2025-12-27")
    assert result["is_temporal_node"] == True
    assert result["shannon_entropy"] > 0.69
```

**API Integration Tests**
```python
def test_enhanced_simulation():
    """Test Gravitonium-enhanced simulation accuracy."""
    params = {
        "gravitonium_coupling": 1000.0,
        "gravitonium_mass_squared": 1e8
    }
    result = simulate_gravitational_waves(params)
    assert "gravitonium_efficiency" in result
```

### Performance Guidelines
- Optimize calculations for real-time visualization
- Cache complex mathematical operations
- Use NumPy vectorization for large arrays
- Implement progressive loading for large datasets

## 🔄 Contribution Workflow

### 1. Issue Creation
- Search existing issues first
- Use appropriate issue templates
- Provide scientific context when relevant
- Tag with appropriate labels

### 2. Branch Naming
```bash
# Feature branches
git checkout -b feature/gravitonium-optimization
git checkout -b feature/new-language-support

# Bug fix branches
git checkout -b fix/temporal-node-calculation
git checkout -b fix/chart-rendering-issue

# Documentation branches
git checkout -b docs/api-reference-update
git checkout -b docs/scientific-methodology
```

### 3. Commit Messages
```bash
# Format: type(scope): description

# Examples:
git commit -m "feat(backend): enhance Gravitonium coupling calculations"
git commit -m "fix(frontend): correct temporal node visualization"
git commit -m "docs(readme): add scientific references"
git commit -m "test(api): add integration tests for enhanced simulation"
```

### 4. Pull Request Process
1. Fill out the PR template completely
2. Ensure all tests pass
3. Update documentation if needed
4. Request review from appropriate maintainers
5. Address review feedback promptly

## 🧪 Testing Guidelines

### Running Tests
```bash
# Backend tests
cd backend
python -m pytest tests/ -v --coverage

# Frontend tests
cd frontend
yarn test --coverage

# Integration tests
python integration_tests/test_full_system.py

# Scientific validation
python tests/test_scientific_accuracy.py
```

### Test Categories
1. **Unit Tests**: Individual function testing
2. **Integration Tests**: API and database interactions
3. **Scientific Tests**: Mathematical accuracy validation
4. **UI Tests**: Frontend component functionality
5. **Performance Tests**: Load and efficiency testing

## 🌍 Localization Guidelines

### Adding New Languages
1. Add language code to `supported_languages` list
2. Create translation entries in `TRANSLATIONS` dictionary
3. Update `FAQ_DATABASE` with localized content
4. Add language selection option in frontend
5. Test all UI elements in new language

### Translation Standards
- Use accurate scientific terminology
- Maintain consistency across all translations
- Consider cultural context for physics concepts
- Provide explanatory notes for complex terms

## 📚 Documentation Standards

### Code Documentation
```python
def enhanced_fractal_calculation(r: float, gravitonium_params: dict) -> dict:
    """
    Enhanced fractal metric tensor calculation with Gravitonium optimization.
    
    This function implements the core FGT equations with Gravitonium field
    corrections as described in Zenodo 16734344.
    
    Mathematical Framework:
        g_{mn}^{E8,H} = η_{mn}(1 + A_f r^{-D_{10,f}})H_{10}(r,t)G_g(r)
        
        Where:
        - D_{10,f} = 1.7 (fractal dimension)
        - G_g(r) = g_g/(m² + r²) (Gravitonium factor)
        - g_g ≈ 10³ (coupling constant)
        - m² ≈ 10⁸ eV² (mass term)
    
    Args:
        r: Spatial scale parameter (1 to 1000)
        gravitonium_params: Dictionary containing:
            - coupling: g_g value (default 1000.0)
            - mass_squared: m² value (default 1e8)
            
    Returns:
        Dictionary containing:
            - tensor_values: Calculated g_{mn} components
            - efficiency: Gravitonium optimization metric
            - harmonic_field: H₁₀ field values
            
    Raises:
        ValueError: If parameters are outside valid ranges
        
    References:
        - Zenodo 16734344: Original FGT theory
        - Zenodo 16738046: Sistema_Cronobinario methodology
        
    Example:
        >>> params = {"coupling": 1000.0, "mass_squared": 1e8}
        >>> result = enhanced_fractal_calculation(100.0, params)
        >>> print(f"Efficiency: {result['efficiency']:.2e}")
    """
```

### API Documentation
- Use OpenAPI/Swagger annotations
- Provide example requests and responses
- Document all parameter constraints
- Include scientific context where relevant

## 🤝 Community Guidelines

### Respectful Collaboration
- Be respectful to all contributors
- Provide constructive feedback
- Help newcomers understand scientific concepts
- Acknowledge contributions appropriately

### Scientific Integrity
- Cite sources for theoretical concepts
- Maintain mathematical rigor
- Question assumptions respectfully
- Validate claims with evidence

### Communication Channels
- **GitHub Issues**: Bug reports, feature requests
- **GitHub Discussions**: General questions, ideas
- **Pull Request Reviews**: Code-specific feedback
- **Scientific Consultations**: Theoretical physics discussions

## 🏆 Recognition

### Contributor Types
- **Core Maintainers**: Long-term project stewards
- **Scientific Advisors**: Physics expertise contributors
- **Technical Contributors**: Code and infrastructure
- **Localization Team**: Translation and cultural adaptation
- **Community Support**: Documentation and user help

### Acknowledgments
All contributors are recognized in:
- Repository contributors list
- Application about section
- Scientific publications (when appropriate)
- Release notes and changelogs

## 📊 Release Process

### Version Numbering
- **Major (X.0.0)**: Breaking changes, new scientific models
- **Minor (2.X.0)**: New features, language support, enhancements
- **Patch (2.0.X)**: Bug fixes, minor improvements

### Release Checklist
- [ ] All tests pass
- [ ] Scientific accuracy validated
- [ ] Documentation updated
- [ ] Translation files complete
- [ ] Performance benchmarks met
- [ ] Security scan passed

## 📞 Getting Help

### For Scientific Questions
- Review scientific references in `/docs/scientific/`
- Check existing GitHub discussions
- Contact scientific advisors through issues

### For Technical Questions
- Check the troubleshooting guide
- Search existing issues
- Join development discussions

### For General Support
- Read the comprehensive README
- Check the FAQ section
- Open a new issue with appropriate template

## 📄 Legal Information

### Licensing
- FracTimeWave is licensed under MIT License
- Contributions are accepted under the same license
- Scientific methodologies may have additional academic requirements

### Attribution
- Maintain original author attribution
- Credit theoretical framework developers
- Acknowledge data sources and references

---

**Thank you for contributing to FracTimeWave!** 🌊

Your contributions help advance our understanding of multidimensional physics and make cutting-edge scientific tools accessible to researchers worldwide.

For questions or clarifications, please open an issue or reach out to the maintainers.

*Together, we're exploring the fractal nature of spacetime and temporal reality.* ⚛️🕐🚀