import requests
import sys
import json
from datetime import datetime

class FracTimeWaveAPITester:
    def __init__(self, base_url="https://ae8868f0-e4a1-4c35-be15-e67d75153b4b.preview.emergentagent.com"):
        self.base_url = base_url
        self.tests_run = 0
        self.tests_passed = 0

    def run_test(self, name, method, endpoint, expected_status, data=None, validate_response=None):
        """Run a single API test"""
        url = f"{self.base_url}/{endpoint}"
        headers = {'Content-Type': 'application/json'}

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=30)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=30)

            success = response.status_code == expected_status
            
            if success:
                try:
                    response_data = response.json()
                    print(f"✅ Passed - Status: {response.status_code}")
                    
                    # Additional validation if provided
                    if validate_response and callable(validate_response):
                        validation_result = validate_response(response_data)
                        if validation_result:
                            print(f"   ✅ Response validation passed")
                        else:
                            print(f"   ⚠️ Response validation failed")
                            success = False
                    
                    # Print key response data
                    if isinstance(response_data, dict):
                        for key, value in list(response_data.items())[:3]:  # Show first 3 keys
                            if isinstance(value, (int, float, str, bool)):
                                print(f"   📊 {key}: {value}")
                    
                except json.JSONDecodeError:
                    print(f"   ⚠️ Response is not valid JSON")
                    success = False
                    response_data = {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {error_data}")
                except:
                    print(f"   Error text: {response.text[:200]}")
                response_data = {}

            if success:
                self.tests_passed += 1
                
            return success, response_data

        except requests.exceptions.Timeout:
            print(f"❌ Failed - Request timeout (30s)")
            return False, {}
        except requests.exceptions.ConnectionError:
            print(f"❌ Failed - Connection error")
            return False, {}
        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def test_health_check(self):
        """Test health check endpoint and verify FracTimeWave branding"""
        def validate_health(data):
            # Check for FracTimeWave branding
            has_fractimewave = data.get('application') == 'FracTimeWave'
            has_theory = 'FracTimeWave' in data.get('theory', '')
            has_author = data.get('author') == 'Danilo Madia'
            has_version = data.get('version') == '2.0.0'
            has_features = isinstance(data.get('features'), list)
            
            print(f"   🏷️ Application: {data.get('application')}")
            print(f"   📚 Theory: {data.get('theory')}")
            print(f"   👤 Author: {data.get('author')}")
            print(f"   🔢 Version: {data.get('version')}")
            print(f"   ⭐ Features: {len(data.get('features', []))} features")
            
            return (has_fractimewave and has_theory and has_author and has_version and has_features)
        
        return self.run_test(
            "Health Check & Branding Verification",
            "GET",
            "api/health",
            200,
            validate_response=validate_health
        )

    def test_supported_languages(self):
        """Test supported languages endpoint"""
        def validate_languages(data):
            languages = data.get('supported_languages', [])
            has_7_languages = len(languages) == 7
            expected_codes = {'it', 'en', 'fr', 'de', 'es', 'ar', 'zh'}
            actual_codes = {lang.get('code') for lang in languages}
            has_all_codes = expected_codes.issubset(actual_codes)
            
            print(f"   🌍 Languages count: {len(languages)}")
            print(f"   🔤 Language codes: {sorted(actual_codes)}")
            
            return (has_7_languages and has_all_codes)
        
        return self.run_test(
            "Supported Languages (7 languages)",
            "GET",
            "api/supported-languages",
            200,
            validate_response=validate_languages
        )

    def test_enhanced_gravitational_simulation(self):
        """Test enhanced gravitational wave simulation with Gravitonium parameters"""
        simulation_params = {
            "r": 100.0,
            "time_steps": 1000,
            "time_max": 1e-6,
            "D_10f": 1.7,
            "amplitude_scale": 1e-5,
            "gravitonium_coupling": 1000.0,
            "gravitonium_mass_squared": 1e8
        }
        
        def validate_simulation(data):
            # Check enhanced FracTimeWave features
            has_gravitonium_factor = 'gravitonium_factor' in data
            has_gravitonium_efficiency = 'gravitonium_efficiency' in data
            has_h_10_harmonic = 'h_10_harmonic' in data
            has_optimization_status = 'FracTimeWave Enhanced' in data.get('optimization_status', '')
            has_time_array = isinstance(data.get('time_array'), list) and len(data.get('time_array', [])) > 0
            has_g_00_values = isinstance(data.get('g_00_values'), list) and len(data.get('g_00_values', [])) > 0
            
            print(f"   🔬 Gravitonium factor: {data.get('gravitonium_factor', 0):.2e}")
            print(f"   ⚡ Gravitonium efficiency: {data.get('gravitonium_efficiency', 0):.2e}")
            print(f"   📈 H₁₀ harmonic: {data.get('h_10_harmonic', 0):.2e}")
            print(f"   📊 Time array length: {len(data.get('time_array', []))}")
            print(f"   🌊 g₀₀ values length: {len(data.get('g_00_values', []))}")
            
            return (has_gravitonium_factor and has_gravitonium_efficiency and 
                   has_h_10_harmonic and has_optimization_status and 
                   has_time_array and has_g_00_values)
        
        return self.run_test(
            "Enhanced Gravitational Simulation (Gravitonium)",
            "POST",
            "api/simulate-gravitational-waves-enhanced",
            200,
            data=simulation_params,
            validate_response=validate_simulation
        )

    def test_enhanced_temporal_node_prediction(self):
        """Test enhanced temporal node prediction with multi-language support"""
        node_params = {
            "date_string": "2025-12-27",
            "language": "en"
        }
        
        def validate_node(data):
            node_analysis = data.get('node_analysis', {})
            is_temporal_node = node_analysis.get('is_temporal_node', False)
            has_status_message = 'status_message' in node_analysis
            has_readable_date = 'readable_date' in node_analysis
            has_binary_code = 'binary_code' in node_analysis
            has_entropy = 'shannon_entropy' in node_analysis
            has_hamming_weight = 'hamming_weight' in node_analysis
            
            print(f"   🎯 Is temporal node: {is_temporal_node}")
            print(f"   💬 Status message: {node_analysis.get('status_message', 'N/A')}")
            print(f"   📅 Readable date: {node_analysis.get('readable_date', 'N/A')}")
            print(f"   🔢 Hamming weight: {node_analysis.get('hamming_weight', 0)}/64")
            print(f"   📈 Shannon entropy: {node_analysis.get('shannon_entropy', 0):.4f}")
            
            return (is_temporal_node and has_status_message and has_readable_date and 
                   has_binary_code and has_entropy and has_hamming_weight)
        
        return self.run_test(
            "Enhanced Temporal Node Prediction (2025-12-27)",
            "POST",
            "api/predict-temporal-node-enhanced",
            200,
            data=node_params,
            validate_response=validate_node
        )

    def test_historical_events(self):
        """Test historical events correlation"""
        event_params = {
            "date": "2025-12-27",
            "language": "en"
        }
        
        def validate_events(data):
            has_date = 'date' in data
            has_events = 'events' in data
            has_language = 'language' in data
            events_list = data.get('events', [])
            
            print(f"   📅 Date: {data.get('date')}")
            print(f"   🌍 Language: {data.get('language')}")
            print(f"   📋 Events found: {len(events_list)}")
            
            if events_list:
                for i, event in enumerate(events_list[:2]):
                    print(f"   📖 Event {i+1}: {event.get('title', 'N/A')}")
            
            return (has_date and has_events and has_language)
        
        return self.run_test(
            "Historical Events Correlation",
            "POST",
            "api/historical-events",
            200,
            data=event_params,
            validate_response=validate_events
        )

    def test_faq_chatbox(self):
        """Test FracTimeWave FAQ ChatBox"""
        chat_params = {
            "message": "What is FracTimeWave?",
            "language": "en",
            "session_id": "test_session_123"
        }
        
        def validate_chat(data):
            has_response = 'response' in data and len(data.get('response', '')) > 0
            has_language = data.get('language') == 'en'
            has_type = data.get('type') == 'faq'
            has_note = 'note' in data
            response_mentions_fractimewave = 'FracTimeWave' in data.get('response', '')
            
            print(f"   💬 Response length: {len(data.get('response', ''))}")
            print(f"   🌍 Language: {data.get('language')}")
            print(f"   🏷️ Type: {data.get('type')}")
            print(f"   🏷️ Mentions FracTimeWave: {response_mentions_fractimewave}")
            
            return (has_response and has_language and has_type and has_note and response_mentions_fractimewave)
        
        return self.run_test(
            "FAQ ChatBox (FracTimeWave query)",
            "POST",
            "api/faq-chatbox",
            200,
            data=chat_params,
            validate_response=validate_chat
        )

    def test_daily_research_monitoring(self):
        """Test daily research monitoring with binary encoding"""
        research_params = {
            "research_query": "FracTimeWave Gravitonium field optimization test",
            "binary_encoding": None
        }
        
        def validate_research(data):
            has_date = 'date' in data
            has_query = data.get('research_query') == research_params['research_query']
            has_binary_encoding = 'binary_encoding' in data and len(data.get('binary_encoding', '')) == 64
            has_hamming_weight = 'hamming_weight' in data
            has_hamming_distance = 'hamming_distance' in data
            has_status = 'FracTimeWave' in data.get('status', '')
            
            print(f"   📅 Date: {data.get('date')}")
            print(f"   🔢 Binary encoding length: {len(data.get('binary_encoding', ''))}")
            print(f"   ⚖️ Hamming weight: {data.get('hamming_weight', 0)}/64")
            print(f"   📏 Hamming distance: {data.get('hamming_distance', 0)}")
            
            return (has_date and has_query and has_binary_encoding and 
                   has_hamming_weight and has_hamming_distance and has_status)
        
        return self.run_test(
            "Daily Research Monitoring (Binary Encoding)",
            "POST",
            "api/daily-research-monitoring",
            200,
            data=research_params,
            validate_response=validate_research
        )

    def test_daily_research_history(self):
        """Test daily research history retrieval"""
        def validate_history(data):
            has_history = 'history' in data
            has_total_entries = 'total_entries' in data
            history_list = data.get('history', [])
            
            print(f"   📋 History entries: {len(history_list)}")
            print(f"   📊 Total entries: {data.get('total_entries', 0)}")
            
            if history_list:
                entry = history_list[0]
                print(f"   📝 Latest entry: {entry.get('research_query', 'N/A')[:50]}...")
            
            return (has_history and has_total_entries)
        
        return self.run_test(
            "Daily Research History",
            "GET",
            "api/daily-research-history?days=30",
            200,
            validate_response=validate_history
        )

    def test_known_temporal_nodes_multilang(self):
        """Test known temporal nodes with multi-language support"""
        def validate_known_nodes(data):
            known_nodes = data.get('known_nodes', [])
            has_nodes = len(known_nodes) > 0
            has_2025_node = any(node.get('date') == '2025-12-27' for node in known_nodes)
            
            print(f"   📋 Found {len(known_nodes)} known nodes")
            print(f"   🎯 Has 2025-12-27 node: {has_2025_node}")
            
            for i, node in enumerate(known_nodes[:2]):
                print(f"   📅 Node {i+1}: {node.get('date', 'N/A')} - {node.get('description', 'N/A')[:50]}...")
                if 'analysis' in node:
                    print(f"      🔬 Analysis available: {node['analysis'].get('is_temporal_node', False)}")
            
            return (has_nodes and has_2025_node)
        
        return self.run_test(
            "Known Temporal Nodes (Multi-language)",
            "GET",
            "api/known-temporal-nodes?language=en",
            200,
            validate_response=validate_known_nodes
        )

    def test_fractal_statistics_multilang(self):
        """Test fractal statistics with language support"""
        r_value = 100
        
        def validate_fractal_stats(data):
            has_fractal_dimension = 'fractal_dimension' in data
            has_scaling_arrays = 'scaling_arrays' in data
            has_language = 'language' in data
            fractal_dim = data.get('fractal_dimension', 0)
            
            print(f"   📐 Fractal dimension: {fractal_dim}")
            print(f"   🌍 Language: {data.get('language')}")
            print(f"   📊 N(r) scaling: {data.get('N_r_scaling', 0):.2e}")
            print(f"   ⏱️ ΔT scaling: {data.get('delta_T_scaling', 0):.2e}")
            
            return (has_fractal_dimension and has_scaling_arrays and 
                   has_language and fractal_dim == 1.7)
        
        return self.run_test(
            "Fractal Statistics (Multi-language)",
            "GET",
            f"api/fractal-statistics/{r_value}?language=en",
            200,
            validate_response=validate_fractal_stats
        )

def main():
    print("🚀 Starting FracTimeWave v2.0.0 Complete API Tests")
    print("=" * 70)
    
    tester = FracTimeWaveAPITester()
    
    # Run all tests
    test_results = []
    
    # Branding and basic functionality
    success, _ = tester.test_health_check()
    test_results.append(("Health Check & Branding", success))
    
    success, _ = tester.test_supported_languages()
    test_results.append(("Multi-language Support", success))
    
    # Enhanced core functionality
    success, _ = tester.test_enhanced_gravitational_simulation()
    test_results.append(("Enhanced Gravitational Simulation", success))
    
    success, _ = tester.test_enhanced_temporal_node_prediction()
    test_results.append(("Enhanced Temporal Node Prediction", success))
    
    # New FracTimeWave features
    success, _ = tester.test_historical_events()
    test_results.append(("Historical Events Correlation", success))
    
    success, _ = tester.test_faq_chatbox()
    test_results.append(("FAQ ChatBox System", success))
    
    success, _ = tester.test_daily_research_monitoring()
    test_results.append(("Daily Research Monitoring", success))
    
    success, _ = tester.test_daily_research_history()
    test_results.append(("Daily Research History", success))
    
    # Multi-language enhanced endpoints
    success, _ = tester.test_known_temporal_nodes_multilang()
    test_results.append(("Known Temporal Nodes (Multi-lang)", success))
    
    success, _ = tester.test_fractal_statistics_multilang()
    test_results.append(("Fractal Statistics (Multi-lang)", success))
    
    # Print final results
    print("\n" + "=" * 70)
    print("📊 FRACTIMEWAVE v2.0.0 FINAL TEST RESULTS")
    print("=" * 70)
    
    for test_name, success in test_results:
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}")
    
    print(f"\n📈 Overall: {tester.tests_passed}/{tester.tests_run} tests passed")
    
    if tester.tests_passed == tester.tests_run:
        print("🎉 All FracTimeWave tests passed! Backend API is fully functional.")
        print("✨ Branding verification: ✅ Complete")
        print("🌍 Multi-language support: ✅ Complete") 
        print("🔬 Enhanced features: ✅ Complete")
        print("📊 Scientific accuracy: ✅ Complete")
        return 0
    else:
        print("⚠️ Some FracTimeWave tests failed. Check the details above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())