"""
FracTimeWave Scientific Accuracy Tests

These tests verify the mathematical and scientific accuracy of FracTimeWave's
implementations of Fractal Graviton Theory and Sistema_Cronobinario.
"""

import pytest
import numpy as np
from datetime import datetime
import sys
import os

# Add backend to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from server import (
    calculate_enhanced_fractal_metric_tensor,
    predict_temporal_node,
    encode_research_to_binary,
    calculate_hamming_distance
)


class TestFractalGravitonTheory:
    """Test core FGT mathematical implementations."""
    
    def test_fractal_dimension_consistency(self):
        """Test that fractal dimension D₁₀,f = 1.7 is consistently applied."""
        r = 100.0
        t = np.linspace(0, 1e-6, 1000)
        D_10f = 1.7
        
        g_00, harmonic, gravitonium_factor = calculate_enhanced_fractal_metric_tensor(
            r, t, D_10f
        )
        
        # Verify fractal scaling
        assert D_10f == 1.7, "Fractal dimension must be 1.7"
        assert len(g_00) == len(t), "Tensor array length must match time array"
        assert gravitonium_factor > 0, "Gravitonium factor must be positive"
        
    def test_gravitonium_parameters(self):
        """Test Gravitonium optimization parameters."""
        r = 100.0
        t = np.linspace(0, 1e-6, 100)
        g_g = 1000.0  # ≈ 10³
        m_squared = 1e8  # ≈ 10⁸ eV²
        
        g_00, harmonic, gravitonium_factor = calculate_enhanced_fractal_metric_tensor(
            r, t, 1.7, 1e-5, g_g, m_squared
        )
        
        # Test parameter ranges
        assert 950 <= g_g <= 1050, "g_g must be within ±5% of 10³"
        assert 0.95e8 <= m_squared <= 1.05e8, "m² must be within ±5% of 10⁸ eV²"
        
        # Test gravitonium factor calculation
        expected_factor = g_g / (m_squared + r**2)
        assert abs(gravitonium_factor - expected_factor) < 1e-10, "Gravitonium factor calculation error"
        
    def test_harmonic_field_frequencies(self):
        """Test H₁₀ harmonic field frequencies."""
        r = 100.0
        t = np.linspace(0, 1e-6, 1000)
        
        g_00, harmonic, gravitonium_factor = calculate_enhanced_fractal_metric_tensor(r, t)
        
        # Test harmonic field properties
        assert len(harmonic) == len(t), "Harmonic field length must match time array"
        assert np.all(np.isfinite(harmonic)), "Harmonic field must contain finite values"
        
        # Test frequency scaling f_i = 10^6/(1+i)
        base_frequency = 1e6
        for i in range(10):
            expected_freq = base_frequency / (1 + i)
            assert expected_freq > 0, f"Frequency {i} must be positive"


class TestSistemaCronobinario:
    """Test temporal analysis and binary encoding systems."""
    
    def test_temporal_node_2025_12_27(self):
        """Test that 2025-12-27 is correctly identified as a temporal node."""
        # Convert date to timestamp
        target_date = datetime(2025, 12, 27)
        timestamp = target_date.timestamp()
        
        result = predict_temporal_node(timestamp)
        
        # Verify temporal node detection
        assert result["is_temporal_node"] == True, "2025-12-27 must be detected as temporal node"
        assert result["shannon_entropy"] > 0.69, "Shannon entropy must be > 0.69 for significant nodes"
        assert result["hamming_weight"] > 0, "Hamming weight must be positive"
        assert len(result["binary_code"]) == 64, "Binary code must be 64 bits"
        
    def test_binary_encoding_accuracy(self):
        """Test SHA-256 binary encoding system."""
        test_query = "FracTimeWave test query"
        test_date = "2025-01-07"
        
        binary_encoding, hamming_weight = encode_research_to_binary(test_query, test_date)
        
        # Verify encoding properties
        assert len(binary_encoding) == 64, "Binary encoding must be exactly 64 bits"
        assert binary_encoding.count('1') == hamming_weight, "Hamming weight must equal '1' bit count"
        assert 0 <= hamming_weight <= 64, "Hamming weight must be between 0 and 64"
        assert all(bit in '01' for bit in binary_encoding), "Binary string must contain only 0s and 1s"
        
    def test_hamming_distance_calculation(self):
        """Test Hamming distance calculations."""
        binary1 = "1010101010101010" + "0" * 48  # 64-bit string
        binary2 = "1010101010101011" + "0" * 48  # 64-bit string (1 bit different)
        
        distance = calculate_hamming_distance(binary1, binary2)
        
        assert distance == 1, "Hamming distance should be 1 for single bit difference"
        
        # Test identical strings
        distance_zero = calculate_hamming_distance(binary1, binary1)
        assert distance_zero == 0, "Hamming distance should be 0 for identical strings"
        
    def test_shannon_entropy_calculation(self):
        """Test Shannon entropy accuracy for temporal analysis."""
        # Test with known binary distribution
        timestamp = datetime(2025, 12, 27).timestamp()
        result = predict_temporal_node(timestamp)
        
        hamming_weight = result["hamming_weight"]
        shannon_entropy = result["shannon_entropy"]
        
        # Calculate expected entropy
        p1 = hamming_weight / 64
        p0 = (64 - hamming_weight) / 64
        
        if p1 > 0 and p0 > 0:
            expected_entropy = -(p1 * np.log2(p1) + p0 * np.log2(p0))
            assert abs(shannon_entropy - expected_entropy) < 1e-10, "Shannon entropy calculation error"


class TestMathematicalConstants:
    """Test that scientific constants are correctly implemented."""
    
    def test_fractal_dimension_value(self):
        """Test that fractal dimension D₁₀,f = 1.7 is used consistently."""
        D_10f = 1.7
        
        # Test scaling relations
        r_test = 100
        N_r_scaling = r_test**(D_10f - 3)  # Should be r^(-1.3)
        T_scaling = r_test**(D_10f - 2)    # Should be r^(-0.3)
        
        assert abs(D_10f - 1.7) < 1e-10, "Fractal dimension must be exactly 1.7"
        assert N_r_scaling > 0, "N(r) scaling must be positive"
        assert T_scaling > 0, "ΔT scaling must be positive"
        
    def test_gravitonium_constants(self):
        """Test Gravitonium field constants."""
        g_g_standard = 1000.0  # 10³
        m_squared_standard = 1e8  # 10⁸ eV²
        
        # Test ±5% tolerance
        g_g_min = 950.0
        g_g_max = 1050.0
        m_squared_min = 0.95e8
        m_squared_max = 1.05e8
        
        assert g_g_min <= g_g_standard <= g_g_max, "g_g must be within tolerance"
        assert m_squared_min <= m_squared_standard <= m_squared_max, "m² must be within tolerance"
        
    def test_frequency_generation(self):
        """Test harmonic frequency generation f_i = 10^6/(1+i) Hz."""
        base_freq = 1e6
        
        for i in range(10):
            frequency = base_freq / (1 + i)
            
            assert frequency > 0, f"Frequency {i} must be positive"
            assert frequency <= base_freq, f"Frequency {i} must be <= base frequency"
            
            if i > 0:
                prev_frequency = base_freq / i
                assert frequency < prev_frequency, f"Frequencies must decrease with i"


class TestNumericalStability:
    """Test numerical stability and precision of calculations."""
    
    def test_tensor_calculation_stability(self):
        """Test that tensor calculations remain stable across parameter ranges."""
        r_values = [1, 10, 100, 1000]
        t = np.linspace(0, 1e-6, 100)
        
        for r in r_values:
            g_00, harmonic, gravitonium_factor = calculate_enhanced_fractal_metric_tensor(r, t)
            
            # Test for numerical stability
            assert np.all(np.isfinite(g_00)), f"Tensor values must be finite for r={r}"
            assert np.all(np.isfinite(harmonic)), f"Harmonic field must be finite for r={r}"
            assert np.isfinite(gravitonium_factor), f"Gravitonium factor must be finite for r={r}"
            
            # Test for reasonable value ranges
            assert np.max(np.abs(g_00)) < 1e10, f"Tensor values must be reasonable for r={r}"
            
    def test_precision_maintenance(self):
        """Test that calculations maintain required precision."""
        # Test with high precision requirements
        r = 100.0
        t = np.linspace(0, 1e-6, 1000)
        
        # Run calculation multiple times
        results = []
        for _ in range(10):
            g_00, harmonic, gravitonium_factor = calculate_enhanced_fractal_metric_tensor(r, t)
            results.append((g_00, harmonic, gravitonium_factor))
        
        # Verify consistency across runs
        for i in range(1, len(results)):
            assert np.allclose(results[0][0], results[i][0], rtol=1e-15), "Tensor calculations must be consistent"
            assert np.allclose(results[0][1], results[i][1], rtol=1e-15), "Harmonic field must be consistent"
            assert abs(results[0][2] - results[i][2]) < 1e-15, "Gravitonium factor must be consistent"


class TestIntegrationAccuracy:
    """Test integration with external systems and data formats."""
    
    def test_timestamp_conversion_accuracy(self):
        """Test timestamp conversion for temporal analysis."""
        # Test known dates
        test_dates = [
            (datetime(2025, 12, 27), "2025-12-27 temporal node"),
            (datetime(2008, 10, 13), "2008-10-13 historical event"),
            (datetime(1970, 1, 20), "Reference timestamp 1.72e9")
        ]
        
        for date_obj, description in test_dates:
            timestamp = date_obj.timestamp()
            
            # Test temporal analysis
            result = predict_temporal_node(timestamp)
            
            assert "timestamp" in result, f"Result must contain timestamp for {description}"
            assert "binary_code" in result, f"Result must contain binary code for {description}"
            assert "shannon_entropy" in result, f"Result must contain entropy for {description}"
            
    def test_multi_language_consistency(self):
        """Test that scientific calculations are consistent across languages."""
        # Test that language settings don't affect calculations
        timestamp = datetime(2025, 12, 27).timestamp()
        
        # Run analysis (language affects only messages, not calculations)
        result = predict_temporal_node(timestamp)
        
        # Core scientific values must be language-independent
        assert isinstance(result["H_10_harmonic"], float), "H₁₀ must be numeric"
        assert isinstance(result["node_strength"], float), "Node strength must be numeric"
        assert isinstance(result["shannon_entropy"], float), "Shannon entropy must be numeric"
        assert isinstance(result["hamming_weight"], int), "Hamming weight must be integer"


# Performance benchmarks
class TestPerformanceBenchmarks:
    """Test performance requirements for real-time calculations."""
    
    def test_simulation_performance(self):
        """Test that simulations complete within acceptable time limits."""
        import time
        
        r = 100.0
        t = np.linspace(0, 1e-6, 10000)  # Large array for performance test
        
        start_time = time.time()
        g_00, harmonic, gravitonium_factor = calculate_enhanced_fractal_metric_tensor(r, t)
        end_time = time.time()
        
        calculation_time = end_time - start_time
        
        # Should complete within reasonable time for UI responsiveness
        assert calculation_time < 5.0, f"Calculation took {calculation_time:.2f}s, should be < 5s"
        
    def test_temporal_analysis_performance(self):
        """Test temporal analysis performance for multiple dates."""
        import time
        
        test_timestamps = [
            datetime(2025, 12, 27).timestamp(),
            datetime(2008, 10, 13).timestamp(),
            datetime(1970, 1, 20).timestamp()
        ]
        
        start_time = time.time()
        
        for timestamp in test_timestamps:
            result = predict_temporal_node(timestamp)
            assert result is not None
            
        end_time = time.time()
        
        total_time = end_time - start_time
        avg_time_per_analysis = total_time / len(test_timestamps)
        
        # Should complete quickly for UI responsiveness
        assert avg_time_per_analysis < 0.1, f"Average analysis time {avg_time_per_analysis:.3f}s too slow"


if __name__ == "__main__":
    # Run all tests
    pytest.main([__file__, "-v", "--tb=short"])