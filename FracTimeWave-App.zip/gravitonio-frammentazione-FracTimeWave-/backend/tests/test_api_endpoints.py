"""
FracTimeWave API Endpoint Tests

Tests for all FastAPI endpoints to ensure correct functionality,
proper error handling, and response formats.
"""

import pytest
import requests
import json
from datetime import datetime
import time


class TestAPIEndpoints:
    """Test all FracTimeWave API endpoints."""
    
    BASE_URL = "http://localhost:8001"
    
    @pytest.fixture(scope="class", autouse=True)
    def setup_class(self):
        """Ensure API server is running before tests."""
        try:
            response = requests.get(f"{self.BASE_URL}/api/health", timeout=5)
            if response.status_code != 200:
                pytest.skip("API server not accessible")
        except requests.exceptions.RequestException:
            pytest.skip("API server not running")
    
    def test_health_endpoint(self):
        """Test health check endpoint."""
        response = requests.get(f"{self.BASE_URL}/api/health")
        
        assert response.status_code == 200
        data = response.json()
        
        assert "status" in data
        assert "application" in data
        assert data["application"] == "FracTimeWave"
        assert "author" in data
        assert data["author"] == "Danilo Madia"
        assert "version" in data
        assert "features" in data
        assert isinstance(data["features"], list)
    
    def test_health_endpoint_multilang(self):
        """Test health endpoint with different languages."""
        languages = ["it", "en", "fr", "de", "es"]
        
        for lang in languages:
            response = requests.get(f"{self.BASE_URL}/api/health?language={lang}")
            assert response.status_code == 200
            
            data = response.json()
            assert "status" in data
            assert "theory" in data
            # Verify response contains FracTimeWave reference
            assert "FracTimeWave" in str(data.values())
    
    def test_supported_languages(self):
        """Test supported languages endpoint."""
        response = requests.get(f"{self.BASE_URL}/api/supported-languages")
        
        assert response.status_code == 200
        data = response.json()
        
        assert "supported_languages" in data
        languages = data["supported_languages"]
        assert len(languages) == 7  # Should support 7 languages
        
        # Check required language codes
        language_codes = [lang["code"] for lang in languages]
        required_codes = ["it", "en", "fr", "de", "es", "ar", "zh"]
        
        for code in required_codes:
            assert code in language_codes, f"Language {code} should be supported"
    
    def test_enhanced_gravitational_simulation(self):
        """Test enhanced gravitational wave simulation endpoint."""
        simulation_params = {
            "r": 100.0,
            "time_steps": 1000,
            "time_max": 1e-6,
            "D_10f": 1.7,
            "amplitude_scale": 1e-5,
            "gravitonium_coupling": 1000.0,
            "gravitonium_mass_squared": 1e8
        }
        
        response = requests.post(
            f"{self.BASE_URL}/api/simulate-gravitational-waves-enhanced",
            json=simulation_params
        )
        
        assert response.status_code == 200
        data = response.json()
        
        # Verify enhanced simulation fields
        assert "simulation_id" in data
        assert "parameters" in data
        assert "time_array" in data
        assert "g_00_values" in data
        assert "h_10_harmonic" in data
        assert "gravitonium_factor" in data
        assert "gravitonium_efficiency" in data
        assert "optimization_status" in data
        
        # Verify data types and ranges
        assert isinstance(data["time_array"], list)
        assert isinstance(data["g_00_values"], list)
        assert len(data["time_array"]) == len(data["g_00_values"])
        assert isinstance(data["h_10_harmonic"], (int, float))
        assert isinstance(data["gravitonium_factor"], (int, float))
        assert "FracTimeWave Enhanced" in data["optimization_status"]
    
    def test_temporal_node_prediction(self):
        """Test enhanced temporal node prediction endpoint."""
        node_params = {
            "date_string": "2025-12-27",
            "language": "en"
        }
        
        response = requests.post(
            f"{self.BASE_URL}/api/predict-temporal-node-enhanced",
            json=node_params
        )
        
        assert response.status_code == 200
        data = response.json()
        
        assert "success" in data
        assert data["success"] == True
        assert "node_analysis" in data
        
        node_analysis = data["node_analysis"]
        
        # Verify all required fields
        required_fields = [
            "timestamp", "H_10_harmonic", "node_strength", 
            "is_temporal_node", "binary_code", "hamming_weight", 
            "shannon_entropy", "readable_date", "status_message"
        ]
        
        for field in required_fields:
            assert field in node_analysis, f"Missing field: {field}"
        
        # Verify 2025-12-27 is detected as temporal node
        assert node_analysis["is_temporal_node"] == True
        assert len(node_analysis["binary_code"]) == 64
        assert 0 <= node_analysis["hamming_weight"] <= 64
        assert isinstance(node_analysis["shannon_entropy"], (int, float))
        assert "2025-12-27" in node_analysis["readable_date"]
    
    def test_temporal_node_different_languages(self):
        """Test temporal node prediction with different languages."""
        languages = ["it", "en", "fr", "de"]
        
        for lang in languages:
            node_params = {
                "date_string": "2025-12-27",
                "language": lang
            }
            
            response = requests.post(
                f"{self.BASE_URL}/api/predict-temporal-node-enhanced",
                json=node_params
            )
            
            assert response.status_code == 200
            data = response.json()
            
            assert data["success"] == True
            node_analysis = data["node_analysis"]
            
            # Scientific values should be the same regardless of language
            assert node_analysis["is_temporal_node"] == True
            assert len(node_analysis["binary_code"]) == 64
            
            # Status message should be localized
            assert "status_message" in node_analysis
    
    def test_historical_events(self):
        """Test historical events endpoint."""
        event_params = {
            "date": "2025-12-27",
            "language": "en"
        }
        
        response = requests.post(
            f"{self.BASE_URL}/api/historical-events",
            json=event_params
        )
        
        assert response.status_code == 200
        data = response.json()
        
        assert "date" in data
        assert "events" in data
        assert "language" in data
        
        assert data["date"] == "2025-12-27"
        assert data["language"] == "en"
        assert isinstance(data["events"], list)
    
    def test_faq_chatbox(self):
        """Test FAQ chatbox endpoint."""
        chat_params = {
            "message": "What is FracTimeWave?",
            "language": "en"
        }
        
        response = requests.post(
            f"{self.BASE_URL}/api/faq-chatbox",
            json=chat_params
        )
        
        assert response.status_code == 200
        data = response.json()
        
        assert "response" in data
        assert "language" in data
        assert "type" in data
        assert "note" in data
        
        assert data["language"] == "en"
        assert data["type"] == "faq"
        assert len(data["response"]) > 0
        assert "FracTimeWave" in data["response"]
    
    def test_faq_chatbox_multilang(self):
        """Test FAQ chatbox with different languages."""
        test_cases = [
            ("it", "Cos'è FracTimeWave?"),
            ("en", "What is FracTimeWave?"),
            ("fr", "Qu'est-ce que FracTimeWave?")
        ]
        
        for lang, message in test_cases:
            chat_params = {
                "message": message,
                "language": lang
            }
            
            response = requests.post(
                f"{self.BASE_URL}/api/faq-chatbox",
                json=chat_params
            )
            
            assert response.status_code == 200
            data = response.json()
            
            assert data["language"] == lang
            assert len(data["response"]) > 0
    
    def test_daily_research_monitoring(self):
        """Test daily research monitoring endpoint."""
        research_params = {
            "research_query": "Advanced Gravitonium field optimization test"
        }
        
        response = requests.post(
            f"{self.BASE_URL}/api/daily-research-monitoring",
            json=research_params
        )
        
        assert response.status_code == 200
        data = response.json()
        
        # Verify all required fields
        required_fields = [
            "date", "research_query", "binary_encoding", 
            "hamming_weight", "hamming_distance", "status"
        ]
        
        for field in required_fields:
            assert field in data, f"Missing field: {field}"
        
        # Verify data types and constraints
        assert len(data["binary_encoding"]) == 64
        assert 0 <= data["hamming_weight"] <= 64
        assert data["hamming_distance"] >= 0
        assert "FracTimeWave" in data["status"]
    
    def test_daily_research_history(self):
        """Test daily research history endpoint."""
        response = requests.get(f"{self.BASE_URL}/api/daily-research-history?days=30")
        
        assert response.status_code == 200
        data = response.json()
        
        assert "history" in data
        assert "total_entries" in data
        assert isinstance(data["history"], list)
        assert isinstance(data["total_entries"], int)
        
        # If there are entries, verify structure
        if data["history"]:
            entry = data["history"][0]
            assert "date" in entry
            assert "research_query" in entry
            assert "binary_encoding" in entry
            assert "hamming_weight" in entry
    
    def test_known_temporal_nodes(self):
        """Test known temporal nodes endpoint."""
        response = requests.get(f"{self.BASE_URL}/api/known-temporal-nodes?language=en")
        
        assert response.status_code == 200
        data = response.json()
        
        assert "known_nodes" in data
        nodes = data["known_nodes"]
        assert isinstance(nodes, list)
        assert len(nodes) >= 2  # Should have at least 2025-12-27 and reference node
        
        # Check for the important 2025-12-27 node
        found_target_node = False
        for node in nodes:
            if node["date"] == "2025-12-27":
                found_target_node = True
                assert "analysis" in node
                assert node["analysis"]["is_temporal_node"] == True
                break
        
        assert found_target_node, "2025-12-27 node should be in known nodes"
    
    def test_fractal_statistics(self):
        """Test fractal statistics endpoint."""
        r_value = 100
        response = requests.get(f"{self.BASE_URL}/api/fractal-statistics/{r_value}?language=en")
        
        assert response.status_code == 200
        data = response.json()
        
        # Verify all required fields
        required_fields = [
            "fractal_dimension", "current_r", "N_r_scaling", 
            "delta_T_scaling", "language", "scaling_arrays"
        ]
        
        for field in required_fields:
            assert field in data, f"Missing field: {field}"
        
        # Verify scientific values
        assert data["fractal_dimension"] == 1.7
        assert data["current_r"] == r_value
        assert isinstance(data["N_r_scaling"], (int, float))
        assert isinstance(data["delta_T_scaling"], (int, float))
        
        # Verify scaling arrays
        scaling_arrays = data["scaling_arrays"]
        assert "r_values" in scaling_arrays
        assert "N_values" in scaling_arrays  
        assert "T_values" in scaling_arrays
        
        for array_name in ["r_values", "N_values", "T_values"]:
            array = scaling_arrays[array_name]
            assert isinstance(array, list)
            assert len(array) > 0
    
    def test_recent_simulations(self):
        """Test recent simulations endpoint."""
        response = requests.get(f"{self.BASE_URL}/api/recent-simulations?limit=5")
        
        assert response.status_code == 200
        data = response.json()
        
        assert "simulations" in data
        simulations = data["simulations"]
        assert isinstance(simulations, list)
        
        # If there are simulations, verify structure
        if simulations:
            simulation = simulations[0]
            assert "simulation_id" in simulation
            assert "parameters" in simulation
            assert "created_at" in simulation
    
    def test_error_handling(self):
        """Test API error handling for invalid requests."""
        # Test invalid simulation parameters
        invalid_params = {
            "r": -100,  # Negative value should cause validation error
            "time_steps": 0
        }
        
        response = requests.post(
            f"{self.BASE_URL}/api/simulate-gravitational-waves-enhanced",
            json=invalid_params
        )
        
        # Should return error status or handle gracefully
        assert response.status_code in [400, 422, 500]
        
        # Test invalid temporal node date
        invalid_node_params = {
            "date_string": "invalid-date-format"
        }
        
        response = requests.post(
            f"{self.BASE_URL}/api/predict-temporal-node-enhanced",
            json=invalid_node_params
        )
        
        # Should return error status or handle gracefully
        assert response.status_code in [400, 422, 500]
    
    def test_api_performance(self):
        """Test API response times for performance."""
        start_time = time.time()
        response = requests.get(f"{self.BASE_URL}/api/health")
        health_time = time.time() - start_time
        
        assert response.status_code == 200
        assert health_time < 1.0, f"Health check took {health_time:.3f}s, should be < 1s"
        
        # Test simulation performance
        simulation_params = {
            "r": 100.0,
            "time_steps": 100,  # Smaller for performance test
            "time_max": 1e-6,
            "D_10f": 1.7
        }
        
        start_time = time.time()
        response = requests.post(
            f"{self.BASE_URL}/api/simulate-gravitational-waves-enhanced",
            json=simulation_params
        )
        simulation_time = time.time() - start_time
        
        assert response.status_code == 200
        assert simulation_time < 5.0, f"Simulation took {simulation_time:.3f}s, should be < 5s"
    
    def test_cors_headers(self):
        """Test CORS headers for frontend integration."""
        response = requests.options(f"{self.BASE_URL}/api/health")
        
        # Should handle CORS preflight requests
        assert response.status_code in [200, 204]
        
        # Test actual request CORS headers
        response = requests.get(f"{self.BASE_URL}/api/health")
        headers = response.headers
        
        # Should have CORS headers (exact headers may vary based on configuration)
        assert response.status_code == 200


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])