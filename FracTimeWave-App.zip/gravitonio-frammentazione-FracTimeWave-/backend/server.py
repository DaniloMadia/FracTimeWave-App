from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import numpy as np
import json
import os
from datetime import datetime, timezone, timedelta
import pymongo
from pymongo import MongoClient
import uuid
import sqlite3
import requests
from pathlib import Path
import hashlib

# MongoDB connection
MONGO_URL = os.environ.get('MONGO_URL', 'mongodb://localhost:27017/')
client = MongoClient(MONGO_URL)
db = client['fractimewave_db']
simulations_collection = db['simulations']
nodes_collection = db['temporal_nodes']
chat_collection = db['chat_history']

# SQLite for daily research monitoring
sqlite_db_path = Path("/app/backend/research_monitoring.db")

app = FastAPI(title="FracTimeWave API", version="2.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Enhanced Pydantic models
class SimulationParams(BaseModel):
    r: float = 100.0
    time_steps: int = 1000
    time_max: float = 1e-6
    D_10f: float = 1.7
    amplitude_scale: float = 1e-5
    gravitonium_coupling: float = 1000.0  # g_g ≈ 10³
    gravitonium_mass_squared: float = 1e8  # m² ≈ 10⁸ eV²

class NodePredictionParams(BaseModel):
    timestamp: Optional[float] = None
    date_string: Optional[str] = None
    language: str = "it"

class ChatMessage(BaseModel):
    message: str
    language: str = "it"
    session_id: Optional[str] = None

class HistoricalEventQuery(BaseModel):
    date: str
    language: str = "it"

class DailyResearchEntry(BaseModel):
    research_query: str
    binary_encoding: Optional[str] = None

# Multi-language support
TRANSLATIONS = {
    "it": {
        "health_status": "Sano",
        "gravitational_wave_title": "Simulazione Onde Gravitazionali FracTimeWave",
        "temporal_node_detected": "Nodo temporale rilevato!",
        "temporal_node_weak": "Nodo temporale debole",
        "historical_events": "Eventi Storici",
        "no_events_found": "Nessun evento trovato per questa data",
        "research_monitoring": "Monitoraggio Ricerca FracTimeWave",
        "binary_encoding": "Codifica Binaria",
        "hamming_weight": "Peso Hamming",
        "fgt_theory": "Teoria FracTimeWave",
        "sistema_cronobinario": "Sistema Cronobinario"
    },
    "en": {
        "health_status": "Healthy",
        "gravitational_wave_title": "FracTimeWave Gravitational Wave Simulation",
        "temporal_node_detected": "Temporal node detected!",
        "temporal_node_weak": "Weak temporal node",
        "historical_events": "Historical Events",
        "no_events_found": "No events found for this date",
        "research_monitoring": "FracTimeWave Research Monitoring",
        "binary_encoding": "Binary Encoding",
        "hamming_weight": "Hamming Weight",
        "fgt_theory": "FracTimeWave Theory",
        "sistema_cronobinario": "Cronobinary System"
    },
    "fr": {
        "health_status": "Sain",
        "gravitational_wave_title": "Simulation d'Ondes Gravitationnelles FracTimeWave",
        "temporal_node_detected": "Nœud temporel détecté!",
        "temporal_node_weak": "Nœud temporel faible",
        "historical_events": "Événements Historiques",
        "no_events_found": "Aucun événement trouvé pour cette date",
        "research_monitoring": "Surveillance FracTimeWave",
        "binary_encoding": "Encodage Binaire",
        "hamming_weight": "Poids de Hamming",
        "fgt_theory": "Théorie FracTimeWave",
        "sistema_cronobinario": "Système Cronobinaire"
    },
    "de": {
        "health_status": "Gesund",
        "gravitational_wave_title": "FracTimeWave Gravitationswellen-Simulation",
        "temporal_node_detected": "Zeitknoten erkannt!",
        "temporal_node_weak": "Schwacher Zeitknoten",
        "historical_events": "Historische Ereignisse",
        "no_events_found": "Keine Ereignisse für dieses Datum gefunden",
        "research_monitoring": "FracTimeWave Forschungsüberwachung",
        "binary_encoding": "Binärkodierung",
        "hamming_weight": "Hamming-Gewicht",
        "fgt_theory": "FracTimeWave-Theorie",
        "sistema_cronobinario": "Cronobinäres System"
    },
    "es": {
        "health_status": "Saludable",
        "gravitational_wave_title": "Simulación de Ondas Gravitacionales FracTimeWave",
        "temporal_node_detected": "¡Nodo temporal detectado!",
        "temporal_node_weak": "Nodo temporal débil",
        "historical_events": "Eventos Históricos",
        "no_events_found": "No se encontraron eventos para esta fecha",
        "research_monitoring": "Monitoreo FracTimeWave",
        "binary_encoding": "Codificación Binaria",
        "hamming_weight": "Peso Hamming",
        "fgt_theory": "Teoría FracTimeWave",
        "sistema_cronobinario": "Sistema Cronobinario"
    },
    "ar": {
        "health_status": "صحي",
        "gravitational_wave_title": "محاكاة الموجات الجاذبية FracTimeWave",
        "temporal_node_detected": "تم اكتشاف عقدة زمنية!",
        "temporal_node_weak": "عقدة زمنية ضعيفة",
        "historical_events": "الأحداث التاريخية",
        "no_events_found": "لم يتم العثور على أحداث لهذا التاريخ",
        "research_monitoring": "مراقبة FracTimeWave",
        "binary_encoding": "الترميز الثنائي",
        "hamming_weight": "وزن هامينغ",
        "fgt_theory": "نظرية FracTimeWave",
        "sistema_cronobinario": "النظام الكرونوثنائي"
    },
    "zh": {
        "health_status": "健康",
        "gravitational_wave_title": "FracTimeWave 引力波模拟",
        "temporal_node_detected": "检测到时间节点！",
        "temporal_node_weak": "弱时间节点",
        "historical_events": "历史事件",
        "no_events_found": "未找到此日期的事件",
        "research_monitoring": "FracTimeWave 研究监控",
        "binary_encoding": "二进制编码",
        "hamming_weight": "汉明重量",
        "fgt_theory": "FracTimeWave 理论",
        "sistema_cronobinario": "时间二进制系统"
    }
}

# Historical events database (1900-2025)
HISTORICAL_EVENTS = {
    "1900-01-01": {"en": "Start of 20th Century", "it": "Inizio del XX Secolo", "events": ["Century transition"]},
    "1905-01-01": {"en": "Einstein's Annus Mirabilis", "it": "Anno Mirabile di Einstein", "events": ["Special Relativity", "Photoelectric Effect"]},
    "1914-06-28": {"en": "Assassination of Archduke Franz Ferdinand", "it": "Assassinio dell'Arciduca Francesco Ferdinando", "events": ["WWI trigger"]},
    "1917-11-07": {"en": "Russian Revolution", "it": "Rivoluzione Russa", "events": ["October Revolution"]},
    "1929-10-29": {"en": "Wall Street Crash", "it": "Crollo di Wall Street", "events": ["Black Tuesday", "Great Depression start"]},
    "1939-09-01": {"en": "World War II begins", "it": "Inizia la Seconda Guerra Mondiale", "events": ["Germany invades Poland"]},
    "1945-08-06": {"en": "Hiroshima atomic bombing", "it": "Bomba atomica su Hiroshima", "events": ["Nuclear age begins"]},
    "1957-10-04": {"en": "Sputnik 1 launched", "it": "Lancio dello Sputnik 1", "events": ["Space age begins"]},
    "1969-07-20": {"en": "Apollo 11 Moon landing", "it": "Allunaggio Apollo 11", "events": ["First human on Moon"]},
    "1989-11-09": {"en": "Berlin Wall falls", "it": "Caduta del Muro di Berlino", "events": ["Cold War ending"]},
    "2001-09-11": {"en": "September 11 attacks", "it": "Attentati dell'11 settembre", "events": ["9/11 attacks"]},
    "2008-10-13": {"en": "Financial crisis peak", "it": "Picco crisi finanziaria", "events": ["Global financial crisis"]},
    "2020-03-11": {"en": "WHO declares COVID-19 pandemic", "it": "OMS dichiara pandemia COVID-19", "events": ["Pandemic start"]},
    "2025-08-10": {"en": "Predicted temporal node", "it": "Nodo temporale previsto", "events": ["FracTimeWave prediction"]},
    "2025-12-27": {"en": "Major temporal node", "it": "Nodo temporale maggiore", "events": ["FracTimeWave major prediction"]}
}

# FAQ Database for FracTimeWave ChatBox
FAQ_DATABASE = {
    "it": {
        "cos_è_fractimewave": {
            "question": "Cos'è FracTimeWave?",
            "answer": "FracTimeWave è l'implementazione avanzata della Fractal Graviton Theory di Danilo Madia, con ottimizzazione Gravitonium e analisi temporale multidimensionale. Include simulazioni a 10D+1, predizioni di nodi temporali, e supporto multilingue."
        },
        "h_10_harmonico": {
            "question": "Cosa significa H₁₀ Harmonico?",
            "answer": "H₁₀ è il campo armonico multidimensionale che modula il tensore metrico in FracTimeWave. È calcolato come somma di 10 modi vibranti con frequenze f_i = 10^6/(1+i) Hz ottimizzate dal campo Gravitonium."
        },
        "gravitonium": {
            "question": "Cosa sono i parametri del Gravitonium?",
            "answer": "Il Gravitonium in FracTimeWave è descritto da: g_g ≈ 10³ (costante di accoppiamento) e m² ≈ 10⁸ eV² (massa al quadrato). Questi parametri ottimizzano l'efficienza computazionale con margine ±5% per stabilità numerica."
        },
        "nodi_temporali": {
            "question": "Come funzionano i nodi temporali in FracTimeWave?",
            "answer": "I nodi temporali sono identificati tramite analisi binaria SHA-256 a 64-bit dei timestamp. FracTimeWave calcola il peso di Hamming, l'entropia di Shannon, e correla con eventi storici per predizioni accurate come il 27/12/2025."
        },
        "ricerca_giornaliera": {
            "question": "Come funziona il monitoraggio ricerca giornaliero?",
            "answer": "FracTimeWave codifica le query di ricerca giornaliere in stringhe binarie a 64-bit usando SHA-256. Calcola peso di Hamming e distanza dal giorno precedente, archiviando pattern in database SQLite per analisi longitudinali."
        }
    },
    "en": {
        "what_is_fractimewave": {
            "question": "What is FracTimeWave?",
            "answer": "FracTimeWave is the advanced implementation of Danilo Madia's Fractal Graviton Theory, featuring Gravitonium optimization and multidimensional temporal analysis. It includes 10D+1 simulations, temporal node predictions, and multilingual support."
        },
        "h_10_harmonic": {
            "question": "What does H₁₀ Harmonic mean?",
            "answer": "H₁₀ is the multidimensional harmonic field that modulates the metric tensor in FracTimeWave. It's calculated as a sum of 10 vibrational modes with frequencies f_i = 10^6/(1+i) Hz optimized by the Gravitonium field."
        },
        "gravitonium": {
            "question": "What are Gravitonium parameters?",
            "answer": "Gravitonium in FracTimeWave is described by: g_g ≈ 10³ (coupling constant) and m² ≈ 10⁸ eV² (mass squared). These parameters optimize computational efficiency with ±5% margin for numerical stability."
        },
        "temporal_nodes": {
            "question": "How do temporal nodes work in FracTimeWave?",
            "answer": "Temporal nodes are identified through 64-bit SHA-256 binary analysis of timestamps. FracTimeWave calculates Hamming weight, Shannon entropy, and correlates with historical events for accurate predictions like 12/27/2025."
        },
        "daily_research": {
            "question": "How does daily research monitoring work?",
            "answer": "FracTimeWave encodes daily research queries into 64-bit binary strings using SHA-256. It calculates Hamming weight and distance from the previous day, storing patterns in SQLite database for longitudinal analysis."
        }
    }
}

def get_translation(key: str, language: str = "it") -> str:
    """Get translated text for given key and language"""
    return TRANSLATIONS.get(language, TRANSLATIONS["it"]).get(key, key)

def initialize_sqlite_db():
    """Initialize SQLite database for daily research monitoring"""
    conn = sqlite3.connect(sqlite_db_path)
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS daily_research (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            research_query TEXT NOT NULL,
            binary_encoding TEXT NOT NULL,
            hamming_weight INTEGER NOT NULL,
            hamming_distance INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(date, research_query)
        )
    ''')
    
    conn.commit()
    conn.close()

# Initialize SQLite on startup
initialize_sqlite_db()

def calculate_enhanced_fractal_metric_tensor(r: float, t: np.ndarray, D_10f: float = 1.7, 
                                           amplitude_scale: float = 1e-5, 
                                           gravitonium_coupling: float = 1000.0,
                                           gravitonium_mass_squared: float = 1e8):
    """
    Enhanced FGT calculation with Gravitonium field optimization for FracTimeWave
    """
    # 10D Minkowski metric
    g_0 = np.eye(10)
    
    # Enhanced fractal amplitude with Gravitonium coupling
    gravitonium_factor = gravitonium_coupling / (gravitonium_mass_squared + r**2)
    fractal_factor = 1 + 0.1 * r**(-D_10f) * gravitonium_factor
    
    # Optimized multi-harmonic field with mass-dependent frequencies
    harmonic_field = np.zeros_like(t)
    for i in range(10):
        frequency = 1e6 / (1 + i) * np.sqrt(gravitonium_mass_squared / 1e8)  # Mass-scaled frequency
        dimension_factor = 1.5 + 0.05 * i
        amplitude = amplitude_scale * r**(2 - dimension_factor) * gravitonium_factor
        harmonic_field += amplitude * np.sin(2 * np.pi * frequency * t)
    
    # Enhanced g_00 component with Gravitonium corrections
    g_00_tensor = g_0[0, 0] * fractal_factor * (1 + harmonic_field)
    
    return g_00_tensor, harmonic_field, gravitonium_factor

def encode_research_to_binary(research_query: str, date: str) -> tuple:
    """Convert research query to 64-bit binary encoding"""
    # Create hash from research query + date
    combined_input = f"{research_query}_{date}".encode('utf-8')
    hash_object = hashlib.sha256(combined_input)
    hash_hex = hash_object.hexdigest()
    
    # Take first 8 bytes (64 bits) of hash
    hash_bytes = bytes.fromhex(hash_hex[:16])
    hash_int = int.from_bytes(hash_bytes, byteorder='big')
    
    # Convert to 64-bit binary string
    binary_encoding = format(hash_int, '064b')
    
    # Calculate Hamming weight
    hamming_weight = binary_encoding.count('1')
    
    return binary_encoding, hamming_weight

def calculate_hamming_distance(binary1: str, binary2: str) -> int:
    """Calculate Hamming distance between two binary strings"""
    return sum(c1 != c2 for c1, c2 in zip(binary1, binary2))

def search_web_for_historical_events(date: str, language: str = "en") -> list:
    """Search web for historical events (placeholder for future implementation)"""
    return []

# API Endpoints
@app.get("/api/health")
async def health_check(language: str = Query("it")):
    return {
        "status": get_translation("health_status", language),
        "theory": get_translation("fgt_theory", language),
        "application": "FracTimeWave",
        "author": "Danilo Madia",
        "version": "2.0.0",
        "features": ["Multi-language", "Historical Events", "Gravitonium Optimization", "Daily Monitoring", "FAQ ChatBox"]
    }

@app.post("/api/simulate-gravitational-waves-enhanced")
async def simulate_gravitational_waves_enhanced(params: SimulationParams):
    """Enhanced FracTimeWave gravitational wave simulation with Gravitonium field optimization"""
    try:
        # Generate time array
        t = np.linspace(0, params.time_max, params.time_steps)
        
        # Calculate enhanced fractal metric tensor with Gravitonium
        g_00_values, harmonic_field, gravitonium_factor = calculate_enhanced_fractal_metric_tensor(
            params.r, t, params.D_10f, params.amplitude_scale,
            params.gravitonium_coupling, params.gravitonium_mass_squared
        )
        
        # Calculate enhanced statistics
        h_10_final = harmonic_field[-1] if len(harmonic_field) > 0 else 0
        gravitonium_efficiency = gravitonium_factor * 1000  # Efficiency metric
        
        # Create enhanced simulation record
        simulation_id = str(uuid.uuid4())
        simulation_result = {
            "simulation_id": simulation_id,
            "parameters": params.dict(),
            "time_array": t.tolist(),
            "g_00_values": g_00_values.tolist(),
            "h_10_harmonic": float(h_10_final),
            "gravitonium_factor": float(gravitonium_factor),
            "gravitonium_efficiency": float(gravitonium_efficiency),
            "optimization_status": "FracTimeWave Enhanced with Gravitonium field",
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        
        # Save to database
        simulation_result_copy = simulation_result.copy()
        simulations_collection.insert_one(simulation_result_copy)
        
        return simulation_result
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"FracTimeWave simulation error: {str(e)}")

@app.post("/api/predict-temporal-node-enhanced")
async def predict_temporal_node_enhanced(params: NodePredictionParams):
    """Enhanced temporal node prediction with multi-language support"""
    try:
        # Determine timestamp
        if params.timestamp:
            timestamp = params.timestamp
        elif params.date_string:
            timestamp = convert_date_to_timestamp(params.date_string)
        else:
            timestamp = 1.72e9
        
        # Enhanced temporal node prediction
        node_analysis = predict_temporal_node(timestamp)
        
        # Add language-specific messages
        readable_date = datetime.fromtimestamp(timestamp, timezone.utc).isoformat()
        node_analysis["readable_date"] = readable_date
        node_analysis["status_message"] = get_translation(
            "temporal_node_detected" if node_analysis["is_temporal_node"] else "temporal_node_weak",
            params.language
        )
        
        # Save to database with language info
        node_record = {
            "node_id": str(uuid.uuid4()),
            "analysis": node_analysis,
            "language": params.language,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        nodes_collection.insert_one(node_record)
        
        return {"success": True, "node_analysis": node_analysis}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"FracTimeWave node prediction error: {str(e)}")

@app.post("/api/historical-events")
async def get_historical_events(query: HistoricalEventQuery):
    """Get historical events for a specific date with multi-language support"""
    try:
        date_key = query.date
        
        # Check local database first
        local_events = HISTORICAL_EVENTS.get(date_key)
        events_list = []
        
        if local_events:
            title = local_events.get(query.language, local_events.get("en", "Unknown Event"))
            events_list.append({
                "date": date_key,
                "title": title,
                "events": local_events.get("events", []),
                "source": "FracTimeWave Database"
            })
        
        # Search web for additional events (placeholder)
        web_events = search_web_for_historical_events(date_key, query.language)
        events_list.extend(web_events)
        
        if not events_list:
            return {
                "date": date_key,
                "message": get_translation("no_events_found", query.language),
                "events": []
            }
        
        return {
            "date": date_key,
            "events": events_list,
            "language": query.language
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"FracTimeWave historical events error: {str(e)}")

@app.post("/api/daily-research-monitoring")
async def daily_research_monitoring(entry: DailyResearchEntry):
    """FracTimeWave daily research monitoring with binary encoding and Hamming analysis"""
    try:
        today = datetime.now().strftime("%Y-%m-%d")
        
        # Generate binary encoding
        binary_encoding, hamming_weight = encode_research_to_binary(entry.research_query, today)
        
        # Calculate Hamming distance from previous day
        conn = sqlite3.connect(sqlite_db_path)
        cursor = conn.cursor()
        
        # Get previous day's data
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        cursor.execute("SELECT binary_encoding FROM daily_research WHERE date = ? ORDER BY id DESC LIMIT 1", (yesterday,))
        prev_result = cursor.fetchone()
        
        hamming_distance = 0
        if prev_result:
            prev_binary = prev_result[0]
            hamming_distance = calculate_hamming_distance(binary_encoding, prev_binary)
        
        # Insert new record
        cursor.execute('''
            INSERT OR REPLACE INTO daily_research 
            (date, research_query, binary_encoding, hamming_weight, hamming_distance)
            VALUES (?, ?, ?, ?, ?)
        ''', (today, entry.research_query, binary_encoding, hamming_weight, hamming_distance))
        
        conn.commit()
        conn.close()
        
        return {
            "date": today,
            "research_query": entry.research_query,
            "binary_encoding": binary_encoding,
            "hamming_weight": hamming_weight,
            "hamming_distance": hamming_distance,
            "status": "FracTimeWave research entry recorded successfully"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"FracTimeWave research monitoring error: {str(e)}")

@app.get("/api/daily-research-history")
async def get_daily_research_history(days: int = Query(30)):
    """Get FracTimeWave daily research history for specified number of days"""
    try:
        conn = sqlite3.connect(sqlite_db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT date, research_query, binary_encoding, hamming_weight, hamming_distance, created_at
            FROM daily_research
            ORDER BY date DESC
            LIMIT ?
        ''', (days,))
        
        results = cursor.fetchall()
        conn.close()
        
        history = []
        for row in results:
            history.append({
                "date": row[0],
                "research_query": row[1],
                "binary_encoding": row[2],
                "hamming_weight": row[3],
                "hamming_distance": row[4],
                "created_at": row[5]
            })
        
        return {
            "history": history,
            "total_entries": len(history)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"FracTimeWave research history error: {str(e)}")

@app.post("/api/faq-chatbox")
async def faq_chatbox(message: ChatMessage):
    """FracTimeWave FAQ-based ChatBox until OpenAI integration"""
    try:
        query = message.message.lower()
        language = message.language
        
        # Get FAQ for language
        faqs = FAQ_DATABASE.get(language, FAQ_DATABASE["en"])
        
        # Simple keyword matching
        best_match = None
        max_matches = 0
        
        for faq_key, faq_data in faqs.items():
            question = faq_data["question"].lower()
            keywords = question.split()
            matches = sum(1 for word in keywords if word in query)
            
            if matches > max_matches:
                max_matches = matches
                best_match = faq_data
        
        # Default response if no good match
        if not best_match or max_matches < 2:
            default_responses = {
                "it": "Mi dispiace, non ho trovato una risposta specifica. Prova a chiedere di: FracTimeWave, Gravitonium, H₁₀ harmonico, nodi temporali, o monitoraggio ricerca.",
                "en": "Sorry, I couldn't find a specific answer. Try asking about: FracTimeWave, Gravitonium, H₁₀ harmonic, temporal nodes, or research monitoring.",
                "fr": "Désolé, je n'ai pas trouvé de réponse spécifique. Essayez de demander sur: FracTimeWave, Gravitonium, harmonique H₁₀, nœuds temporels, ou surveillance de recherche.",
                "de": "Entschuldigung, ich konnte keine spezifische Antwort finden. Versuchen Sie zu fragen nach: FracTimeWave, Gravitonium, H₁₀ harmonisch, Zeitknoten, oder Forschungsüberwachung.",
                "es": "Lo siento, no pude encontrar una respuesta específica. Trate de preguntar sobre: FracTimeWave, Gravitonium, armónico H₁₀, nodos temporales, o monitoreo de investigación.",
                "ar": "آسف، لم أتمكن من العثور على إجابة محددة. حاول السؤال عن: FracTimeWave، Gravitonium، التوافقي H₁₀، العقد الزمنية، أو مراقبة البحث.",
                "zh": "抱歉，我找不到具体答案。尝试询问：FracTimeWave、引力子、H₁₀谐波、时间节点或研究监控。"
            }
            
            response_text = default_responses.get(language, default_responses["en"])
        else:
            response_text = best_match["answer"]
        
        # Save chat history
        chat_record = {
            "session_id": message.session_id or str(uuid.uuid4()),
            "user_message": message.message,
            "bot_response": response_text,
            "language": language,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
        chat_collection.insert_one(chat_record)
        
        return {
            "response": response_text,
            "language": language,
            "type": "faq",
            "note": "FracTimeWave FAQ-based response. Advanced AI integration available with API key."
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"FracTimeWave ChatBox error: {str(e)}")

@app.get("/api/supported-languages")
async def get_supported_languages():
    """Get list of supported languages for FracTimeWave"""
    languages = [
        {"code": "it", "name": "Italian", "native": "Italiano"},
        {"code": "en", "name": "English", "native": "English"},
        {"code": "fr", "name": "French", "native": "Français"},
        {"code": "de", "name": "German", "native": "Deutsch"},
        {"code": "es", "name": "Spanish", "native": "Español"},
        {"code": "ar", "name": "Arabic", "native": "العربية"},
        {"code": "zh", "name": "Chinese", "native": "中文"}
    ]
    
    return {"supported_languages": languages}

# Keep existing endpoints for backward compatibility
@app.post("/api/simulate-gravitational-waves")
async def simulate_gravitational_waves(params: SimulationParams):
    """Original simulation endpoint for backward compatibility"""
    return await simulate_gravitational_waves_enhanced(params)

@app.post("/api/predict-temporal-node")
async def predict_temporal_node_endpoint(params: NodePredictionParams):
    """Original prediction endpoint for backward compatibility"""
    return await predict_temporal_node_enhanced(params)

# Helper functions from original implementation
def convert_date_to_timestamp(date_string: str) -> float:
    """Convert date string to Unix timestamp"""
    try:
        dt = datetime.fromisoformat(date_string.replace('Z', '+00:00'))
        return dt.timestamp()
    except:
        for fmt in ['%Y-%m-%d', '%Y-%m-%d %H:%M:%S', '%d/%m/%Y']:
            try:
                dt = datetime.strptime(date_string, fmt)
                return dt.timestamp()
            except:
                continue
        raise ValueError("Invalid date format")

def predict_temporal_node(timestamp: float):
    """Original temporal node prediction algorithm"""
    H_10 = 0
    for i in range(10):
        frequency = 1e6 / (1 + i)
        H_10 += 1e-5 * np.sin(2 * np.pi * frequency * timestamp)
    
    node_strength = abs(H_10)
    is_node = node_strength > 0.00001
    
    timestamp_int = int(timestamp)
    binary_code = format(timestamp_int, '064b')
    
    hamming_weight = binary_code.count('1')
    shannon_entropy = -np.sum([p * np.log2(p) if p > 0 else 0 
                              for p in [hamming_weight/64, (64-hamming_weight)/64]])
    
    return {
        "timestamp": timestamp,
        "H_10_harmonic": float(H_10),
        "node_strength": float(node_strength),
        "is_temporal_node": bool(is_node),
        "binary_code": binary_code,
        "hamming_weight": hamming_weight,
        "shannon_entropy": float(shannon_entropy)
    }

@app.get("/api/known-temporal-nodes")
async def get_known_nodes(language: str = Query("it")):
    """Get known temporal nodes with language support"""
    known_nodes = [
        {
            "date": "2025-12-27",
            "timestamp": datetime(2025, 12, 27).timestamp(),
            "description": get_translation("temporal_node_detected", language),
            "significance": "High probability transition point",
            "theory_reference": "FracTimeWave Zenodo 16734344"
        },
        {
            "date": "1970-01-20",
            "timestamp": 1.72e9,
            "description": "Reference node from mathematical analysis",
            "significance": "Computational reference point",
            "theory_reference": "FracTimeWave Sistema_Cronobinario"
        }
    ]
    
    for node in known_nodes:
        node["analysis"] = predict_temporal_node(node["timestamp"])
    
    return {"known_nodes": known_nodes}

@app.get("/api/fractal-statistics/{r}")
async def get_fractal_statistics(r: float, language: str = Query("it")):
    """Get fractal statistics with language support"""
    D_10f = 1.7
    
    N_r = r**(D_10f - 3)
    delta_T = r**(D_10f - 2)
    
    r_array = np.logspace(-2, 3, 50)
    N_array = r_array**(D_10f - 3)
    T_array = r_array**(D_10f - 2)
    
    return {
        "fractal_dimension": D_10f,
        "current_r": r,
        "N_r_scaling": float(N_r),
        "delta_T_scaling": float(delta_T),
        "language": language,
        "scaling_arrays": {
            "r_values": r_array.tolist(),
            "N_values": N_array.tolist(),
            "T_values": T_array.tolist()
        }
    }

@app.get("/api/recent-simulations")
async def get_recent_simulations(limit: int = 10):
    """Get recent FracTimeWave simulation results"""
    try:
        simulations = list(simulations_collection.find(
            {}, {"_id": 0}
        ).sort("created_at", -1).limit(limit))
        
        return {"simulations": simulations}
    except Exception as e:
        return {"simulations": [], "error": str(e)}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)