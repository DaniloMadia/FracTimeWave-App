---
name: Bug Report
about: Create a report to help us improve FracTimeWave
title: '[BUG] '
labels: bug
assignees: ''

---

## Bug Description
A clear and concise description of what the bug is.

## To Reproduce
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

## Expected Behavior
A clear and concise description of what you expected to happen.

## Screenshots
If applicable, add screenshots to help explain your problem.

## Environment Information
- **FracTimeWave Version**: [e.g. v2.0.0]
- **Browser**: [e.g. chrome, safari]
- **Operating System**: [e.g. iOS, Windows, Linux]
- **Language Setting**: [e.g. English, Italian]

## Scientific Context (if applicable)
- **Simulation Parameters**: [e.g. r=100, D_10f=1.7]
- **Gravitonium Settings**: [e.g. g_g=1000, m²=1e8]
- **Temporal Analysis**: [e.g. date being analyzed]

## Additional Context
Add any other context about the problem here, including:
- Error messages from browser console
- Backend logs if available
- Network requests that failed

## Checklist
- [ ] I have searched existing issues for duplicates
- [ ] I have included all relevant information
- [ ] This bug affects the scientific calculations (high priority)
- [ ] This is a UI/UX issue (medium priority)
- [ ] This is a documentation issue (low priority)