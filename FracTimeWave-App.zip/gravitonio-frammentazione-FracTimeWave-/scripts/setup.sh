#!/bin/bash

# FracTimeWave Development Setup Script
# This script sets up the complete development environment

set -e  # Exit on any error

echo "🌊 FracTimeWave Development Setup"
echo "=================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "\n${BLUE}$1${NC}"
}

# Check if running on supported OS
check_os() {
    print_header "Checking Operating System..."
    
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        OS="linux"
        print_status "Linux detected"
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="mac"
        print_status "macOS detected"
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
        OS="windows"
        print_status "Windows detected"
    else
        print_error "Unsupported operating system: $OSTYPE"
        exit 1
    fi
}

# Check prerequisites
check_prerequisites() {
    print_header "Checking Prerequisites..."
    
    # Check Python
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
        print_status "Python $PYTHON_VERSION found"
        
        # Check if Python version is 3.11+
        if [[ $(echo "$PYTHON_VERSION" | cut -d'.' -f2) -lt 11 ]]; then
            print_warning "Python 3.11+ recommended for optimal performance"
        fi
    else
        print_error "Python 3 not found. Please install Python 3.11+"
        exit 1
    fi
    
    # Check Node.js
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node --version | sed 's/v//')
        print_status "Node.js $NODE_VERSION found"
        
        # Check if Node version is 18+
        if [[ $(echo "$NODE_VERSION" | cut -d'.' -f1) -lt 18 ]]; then
            print_warning "Node.js 18+ recommended"
        fi
    else
        print_error "Node.js not found. Please install Node.js 18+"
        exit 1
    fi
    
    # Check Yarn
    if command -v yarn &> /dev/null; then
        YARN_VERSION=$(yarn --version)
        print_status "Yarn $YARN_VERSION found"
    else
        print_warning "Yarn not found. Installing via npm..."
        npm install -g yarn
    fi
    
    # Check Git
    if command -v git &> /dev/null; then
        print_status "Git found"
    else
        print_error "Git not found. Please install Git"
        exit 1
    fi
    
    # Check Docker (optional)
    if command -v docker &> /dev/null; then
        print_status "Docker found - container deployment available"
    else
        print_warning "Docker not found - container features unavailable"
    fi
}

# Setup environment files
setup_environment() {
    print_header "Setting Up Environment Configuration..."
    
    if [[ ! -f ".env" ]]; then
        cp .env.example .env
        print_status "Created .env file from template"
        print_warning "Please edit .env file with your specific configuration"
    else
        print_status "Environment file already exists"
    fi
    
    # Create backend .env if it doesn't exist
    if [[ ! -f "backend/.env" ]]; then
        cat > backend/.env << EOF
MONGO_URL=mongodb://localhost:27017/fractimewave_db
ENVIRONMENT=development
DEBUG=true
LOG_LEVEL=info
EOF
        print_status "Created backend/.env file"
    fi
    
    # Create frontend .env if it doesn't exist
    if [[ ! -f "frontend/.env" ]]; then
        cat > frontend/.env << EOF
REACT_APP_BACKEND_URL=http://localhost:8001
REACT_APP_VERSION=2.0.0
REACT_APP_ENVIRONMENT=development
EOF
        print_status "Created frontend/.env file"
    fi
}

# Setup backend
setup_backend() {
    print_header "Setting Up Backend (Python/FastAPI)..."
    
    cd backend
    
    # Create virtual environment
    if [[ ! -d "venv" ]]; then
        print_status "Creating Python virtual environment..."
        python3 -m venv venv
    fi
    
    # Activate virtual environment
    if [[ "$OS" == "windows" ]]; then
        source venv/Scripts/activate
    else
        source venv/bin/activate
    fi
    
    # Install dependencies
    print_status "Installing Python dependencies..."
    pip install --upgrade pip
    pip install -r requirements.txt
    
    print_status "Backend setup completed"
    cd ..
}

# Setup frontend
setup_frontend() {
    print_header "Setting Up Frontend (React)..."
    
    cd frontend
    
    # Install dependencies
    print_status "Installing Node.js dependencies..."
    yarn install
    
    print_status "Frontend setup completed"
    cd ..
}

# Setup database
setup_database() {
    print_header "Setting Up Database..."
    
    if command -v docker &> /dev/null; then
        print_status "Starting MongoDB with Docker..."
        docker run -d \
            --name fractimewave-mongo \
            -p 27017:27017 \
            -v fractimewave_data:/data/db \
            mongo:7.0
        
        # Wait for MongoDB to start
        sleep 5
        print_status "MongoDB started in Docker container"
    else
        print_warning "Docker not available. Please install MongoDB manually:"
        print_warning "https://docs.mongodb.com/manual/installation/"
    fi
}

# Create necessary directories
create_directories() {
    print_header "Creating Project Directories..."
    
    directories=(
        "logs"
        "data"
        "backup"
        "tests/integration"
        "docs/scientific"
        "scripts/deployment"
    )
    
    for dir in "${directories[@]}"; do
        if [[ ! -d "$dir" ]]; then
            mkdir -p "$dir"
            print_status "Created directory: $dir"
        fi
    done
}

# Verify installation
verify_installation() {
    print_header "Verifying Installation..."
    
    # Test backend
    print_status "Testing backend..."
    cd backend
    if [[ "$OS" == "windows" ]]; then
        source venv/Scripts/activate
    else
        source venv/bin/activate
    fi
    
    # Start backend in background
    python server.py &
    BACKEND_PID=$!
    
    # Wait for backend to start
    sleep 10
    
    # Test health endpoint
    if curl -f http://localhost:8001/api/health &> /dev/null; then
        print_status "Backend API responding correctly"
    else
        print_error "Backend API not responding"
        kill $BACKEND_PID 2>/dev/null || true
        cd ..
        exit 1
    fi
    
    # Stop backend
    kill $BACKEND_PID 2>/dev/null || true
    cd ..
    
    # Test frontend build
    print_status "Testing frontend build..."
    cd frontend
    yarn build &> /dev/null
    
    if [[ -d "build" ]]; then
        print_status "Frontend builds successfully"
        rm -rf build
    else
        print_error "Frontend build failed"
        cd ..
        exit 1
    fi
    cd ..
}

# Main execution
main() {
    check_os
    check_prerequisites
    create_directories
    setup_environment
    setup_database
    setup_backend
    setup_frontend
    verify_installation
    
    print_header "🎉 FracTimeWave Setup Complete!"
    echo ""
    print_status "Next steps:"
    echo "1. Edit .env files with your configuration"
    echo "2. Start the development servers:"
    echo "   - Backend: cd backend && source venv/bin/activate && python server.py"
    echo "   - Frontend: cd frontend && yarn start"
    echo "3. Visit http://localhost:3000 to access FracTimeWave"
    echo ""
    print_status "For Docker deployment:"
    echo "   docker-compose up -d"
    echo ""
    print_status "Documentation: https://github.com/danilo-madia/fractimewave"
    print_status "Issues: https://github.com/danilo-madia/fractimewave/issues"
}

# Run main function
main "$@"