import requests
import sys
import json
from datetime import datetime

class FractalGravitonAPITester:
    def __init__(self, base_url="https://ae8868f0-e4a1-4c35-be15-e67d75153b4b.preview.emergentagent.com"):
        self.base_url = base_url
        self.tests_run = 0
        self.tests_passed = 0

    def run_test(self, name, method, endpoint, expected_status, data=None, validate_response=None):
        """Run a single API test"""
        url = f"{self.base_url}/{endpoint}"
        headers = {'Content-Type': 'application/json'}

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=30)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=30)

            success = response.status_code == expected_status
            
            if success:
                try:
                    response_data = response.json()
                    print(f"✅ Passed - Status: {response.status_code}")
                    
                    # Additional validation if provided
                    if validate_response and callable(validate_response):
                        validation_result = validate_response(response_data)
                        if validation_result:
                            print(f"   ✅ Response validation passed: {validation_result}")
                        else:
                            print(f"   ⚠️ Response validation failed")
                            success = False
                    
                    # Print key response data
                    if isinstance(response_data, dict):
                        for key, value in list(response_data.items())[:3]:  # Show first 3 keys
                            if isinstance(value, (int, float, str, bool)):
                                print(f"   📊 {key}: {value}")
                    
                except json.JSONDecodeError:
                    print(f"   ⚠️ Response is not valid JSON")
                    success = False
                    response_data = {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {error_data}")
                except:
                    print(f"   Error text: {response.text[:200]}")
                response_data = {}

            if success:
                self.tests_passed += 1
                
            return success, response_data

        except requests.exceptions.Timeout:
            print(f"❌ Failed - Request timeout (30s)")
            return False, {}
        except requests.exceptions.ConnectionError:
            print(f"❌ Failed - Connection error")
            return False, {}
        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def test_health_check(self):
        """Test health check endpoint"""
        def validate_health(data):
            return (data.get('status') == 'healthy' and 
                   'theory' in data and 
                   'author' in data)
        
        return self.run_test(
            "Health Check",
            "GET",
            "api/health",
            200,
            validate_response=validate_health
        )

    def test_gravitational_simulation(self):
        """Test gravitational wave simulation with known working parameters"""
        simulation_params = {
            "r": 100.0,
            "time_steps": 1000,
            "time_max": 1e-6,
            "D_10f": 1.7,
            "amplitude_scale": 1e-5
        }
        
        def validate_simulation(data):
            # Check if H_10 harmonic values are around 10^-4 as expected
            h_10 = data.get('h_10_harmonic', 0)
            has_time_array = isinstance(data.get('time_array'), list) and len(data.get('time_array', [])) > 0
            has_g_00_values = isinstance(data.get('g_00_values'), list) and len(data.get('g_00_values', [])) > 0
            has_simulation_id = 'simulation_id' in data
            
            print(f"   📈 H_10 harmonic: {h_10:.2e}")
            print(f"   📊 Time array length: {len(data.get('time_array', []))}")
            print(f"   📊 g_00 values length: {len(data.get('g_00_values', []))}")
            
            return (has_time_array and has_g_00_values and has_simulation_id and
                   abs(h_10) > 1e-6)  # Should have some harmonic value
        
        return self.run_test(
            "Gravitational Wave Simulation",
            "POST",
            "api/simulate-gravitational-waves",
            200,
            data=simulation_params,
            validate_response=validate_simulation
        )

    def test_temporal_node_prediction_date(self):
        """Test temporal node prediction with 2025-12-27 (should be detected as temporal node)"""
        node_params = {
            "date_string": "2025-12-27"
        }
        
        def validate_node(data):
            node_analysis = data.get('node_analysis', {})
            is_temporal_node = node_analysis.get('is_temporal_node', False)
            has_binary_code = 'binary_code' in node_analysis
            has_entropy = 'shannon_entropy' in node_analysis
            has_hamming_weight = 'hamming_weight' in node_analysis
            
            print(f"   🎯 Is temporal node: {is_temporal_node}")
            print(f"   📊 H_10 harmonic: {node_analysis.get('H_10_harmonic', 0):.2e}")
            print(f"   🔢 Hamming weight: {node_analysis.get('hamming_weight', 0)}/64")
            print(f"   📈 Shannon entropy: {node_analysis.get('shannon_entropy', 0):.4f}")
            
            return (is_temporal_node and has_binary_code and has_entropy and has_hamming_weight)
        
        return self.run_test(
            "Temporal Node Prediction (2025-12-27)",
            "POST",
            "api/predict-temporal-node",
            200,
            data=node_params,
            validate_response=validate_node
        )

    def test_temporal_node_prediction_timestamp(self):
        """Test temporal node prediction with timestamp 1.72e9 (should produce strong node signal)"""
        node_params = {
            "timestamp": 1.72e9
        }
        
        def validate_node(data):
            node_analysis = data.get('node_analysis', {})
            node_strength = node_analysis.get('node_strength', 0)
            has_readable_date = 'readable_date' in node_analysis
            
            print(f"   💪 Node strength: {node_strength:.2e}")
            print(f"   📅 Readable date: {node_analysis.get('readable_date', 'N/A')}")
            
            return (node_strength > 0 and has_readable_date)
        
        return self.run_test(
            "Temporal Node Prediction (1.72e9 timestamp)",
            "POST",
            "api/predict-temporal-node",
            200,
            data=node_params,
            validate_response=validate_node
        )

    def test_known_temporal_nodes(self):
        """Test known temporal nodes endpoint"""
        def validate_known_nodes(data):
            known_nodes = data.get('known_nodes', [])
            has_nodes = len(known_nodes) > 0
            
            if has_nodes:
                print(f"   📋 Found {len(known_nodes)} known nodes")
                for i, node in enumerate(known_nodes[:2]):  # Show first 2
                    print(f"   📅 Node {i+1}: {node.get('date', 'N/A')} - {node.get('description', 'N/A')}")
            
            return has_nodes
        
        return self.run_test(
            "Known Temporal Nodes",
            "GET",
            "api/known-temporal-nodes",
            200,
            validate_response=validate_known_nodes
        )

    def test_fractal_statistics(self):
        """Test fractal statistics endpoint"""
        r_value = 100
        
        def validate_fractal_stats(data):
            has_fractal_dimension = 'fractal_dimension' in data
            has_scaling_arrays = 'scaling_arrays' in data
            fractal_dim = data.get('fractal_dimension', 0)
            
            print(f"   📐 Fractal dimension: {fractal_dim}")
            print(f"   📊 N(r) scaling: {data.get('N_r_scaling', 0):.2e}")
            print(f"   ⏱️ ΔT scaling: {data.get('delta_T_scaling', 0):.2e}")
            
            return (has_fractal_dimension and has_scaling_arrays and fractal_dim == 1.7)
        
        return self.run_test(
            "Fractal Statistics",
            "GET",
            f"api/fractal-statistics/{r_value}",
            200,
            validate_response=validate_fractal_stats
        )

    def test_recent_simulations(self):
        """Test recent simulations endpoint"""
        def validate_recent_sims(data):
            simulations = data.get('simulations', [])
            print(f"   📋 Found {len(simulations)} recent simulations")
            return isinstance(simulations, list)
        
        return self.run_test(
            "Recent Simulations",
            "GET",
            "api/recent-simulations",
            200,
            validate_response=validate_recent_sims
        )

def main():
    print("🚀 Starting Fractal Graviton Theory API Tests")
    print("=" * 60)
    
    tester = FractalGravitonAPITester()
    
    # Run all tests
    test_results = []
    
    # Basic health check
    success, _ = tester.test_health_check()
    test_results.append(("Health Check", success))
    
    # Core functionality tests
    success, _ = tester.test_gravitational_simulation()
    test_results.append(("Gravitational Simulation", success))
    
    success, _ = tester.test_temporal_node_prediction_date()
    test_results.append(("Temporal Node (Date)", success))
    
    success, _ = tester.test_temporal_node_prediction_timestamp()
    test_results.append(("Temporal Node (Timestamp)", success))
    
    # Additional endpoints
    success, _ = tester.test_known_temporal_nodes()
    test_results.append(("Known Temporal Nodes", success))
    
    success, _ = tester.test_fractal_statistics()
    test_results.append(("Fractal Statistics", success))
    
    success, _ = tester.test_recent_simulations()
    test_results.append(("Recent Simulations", success))
    
    # Print final results
    print("\n" + "=" * 60)
    print("📊 FINAL TEST RESULTS")
    print("=" * 60)
    
    for test_name, success in test_results:
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}")
    
    print(f"\n📈 Overall: {tester.tests_passed}/{tester.tests_run} tests passed")
    
    if tester.tests_passed == tester.tests_run:
        print("🎉 All tests passed! Backend API is working correctly.")
        return 0
    else:
        print("⚠️ Some tests failed. Check the details above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())