# FracTimeWave Deployment Guide

This document provides comprehensive instructions for deploying FracTimeWave in various environments, from local development to production cloud deployment.

## 🚀 Quick Deployment Options

### Option 1: Docker Compose (Recommended)
```bash
git clone https://github.com/danilo-madia/fractimewave.git
cd fractimewave
docker-compose up -d
```
Access: http://localhost:3000

### Option 2: Development Setup
```bash
git clone https://github.com/danilo-madia/fractimewave.git
cd fractimewave
chmod +x scripts/setup.sh
./scripts/setup.sh
```

### Option 3: Cloud Deployment
See [Cloud Deployment](#cloud-deployment) section below.

---

## 📋 Prerequisites

### System Requirements
- **CPU**: 2+ cores recommended for scientific calculations
- **RAM**: 4GB minimum, 8GB recommended
- **Storage**: 10GB for application and data
- **Network**: Internet connection for external APIs (optional)

### Software Dependencies
- **Docker & Docker Compose** (recommended) OR
- **Python 3.11+** with pip
- **Node.js 18+** with yarn/npm
- **MongoDB 7.0+**
- **Git**

### Port Requirements
- **3000**: Frontend (React application)
- **8001**: Backend API (FastAPI)
- **27017**: MongoDB database
- **80/443**: Production web server (optional)

---

## 🐳 Docker Deployment

### Standard Docker Compose

1. **Clone and Configure**
```bash
git clone https://github.com/danilo-madia/fractimewave.git
cd fractimewave
cp .env.example .env
# Edit .env with your configuration
```

2. **Deploy Services**
```bash
docker-compose up -d
```

3. **Verify Deployment**
```bash
docker-compose ps
curl http://localhost:8001/api/health
curl http://localhost:3000
```

### Production Docker Compose

```yaml
# docker-compose.prod.yml
version: '3.8'
services:
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/prod.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/ssl/certs:ro
  
  backend:
    build: ./backend
    environment:
      - MONGO_URL=mongodb://mongo:27017/fractimewave_prod
      - ENVIRONMENT=production
      - DEBUG=false
    depends_on:
      - mongo
      
  frontend:
    build: 
      context: ./frontend
      args:
        - REACT_APP_BACKEND_URL=https://api.yourdomain.com
    depends_on:
      - backend
```

```bash
docker-compose -f docker-compose.prod.yml up -d
```

---

## 🛠️ Manual Deployment

### Backend Deployment

1. **Environment Setup**
```bash
cd backend
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

2. **Configuration**
```bash
cp .env.example .env
# Edit .env with your MongoDB connection and settings
```

3. **Database Setup**
```bash
# Start MongoDB
mongod --dbpath /path/to/data/directory

# Or use Docker
docker run -d -p 27017:27017 --name mongo mongo:7.0
```

4. **Start Backend**
```bash
python server.py
```

Backend will be available at: http://localhost:8001

### Frontend Deployment

1. **Environment Setup**
```bash
cd frontend
yarn install
```

2. **Configuration**
```bash
cp .env.example .env
# Set REACT_APP_BACKEND_URL to your backend URL
```

3. **Development Server**
```bash
yarn start
```

4. **Production Build**
```bash
yarn build
# Serve build directory with nginx or any static file server
```

---

## ☁️ Cloud Deployment

### AWS Deployment

#### Using AWS ECS with Docker

1. **Build and Push Images**
```bash
# Build images
docker build -t fractimewave-backend ./backend
docker build -t fractimewave-frontend ./frontend

# Tag for ECR
docker tag fractimewave-backend:latest YOUR_ECR_URI/fractimewave-backend:latest
docker tag fractimewave-frontend:latest YOUR_ECR_URI/fractimewave-frontend:latest

# Push to ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin YOUR_ECR_URI
docker push YOUR_ECR_URI/fractimewave-backend:latest
docker push YOUR_ECR_URI/fractimewave-frontend:latest
```

2. **ECS Task Definition**
```json
{
  "family": "fractimewave",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "1024",
  "memory": "2048",
  "executionRoleArn": "arn:aws:iam::ACCOUNT:role/ecsTaskExecutionRole",
  "containerDefinitions": [
    {
      "name": "backend",
      "image": "YOUR_ECR_URI/fractimewave-backend:latest",
      "portMappings": [{"containerPort": 8001}],
      "environment": [
        {"name": "MONGO_URL", "value": "mongodb://mongo-cluster:27017/fractimewave"},
        {"name": "ENVIRONMENT", "value": "production"}
      ]
    },
    {
      "name": "frontend",
      "image": "YOUR_ECR_URI/fractimewave-frontend:latest",
      "portMappings": [{"containerPort": 3000}]
    }
  ]
}
```

#### Using AWS Lambda + API Gateway (Serverless)

```bash
# Install serverless framework
npm install -g serverless

# Deploy backend as Lambda functions
cd backend
serverless deploy --stage prod

# Deploy frontend to S3 + CloudFront
cd ../frontend
yarn build
aws s3 sync build/ s3://your-bucket-name
aws cloudfront create-invalidation --distribution-id YOUR_DIST_ID --paths "/*"
```

### Google Cloud Platform

#### Using Google Cloud Run

```bash
# Build and push to Google Container Registry
gcloud builds submit --tag gcr.io/YOUR_PROJECT/fractimewave-backend ./backend
gcloud builds submit --tag gcr.io/YOUR_PROJECT/fractimewave-frontend ./frontend

# Deploy to Cloud Run
gcloud run deploy fractimewave-backend \
  --image gcr.io/YOUR_PROJECT/fractimewave-backend \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated

gcloud run deploy fractimewave-frontend \
  --image gcr.io/YOUR_PROJECT/fractimewave-frontend \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated
```

### Microsoft Azure

#### Using Azure Container Instances

```bash
# Create resource group
az group create --name fractimewave-rg --location eastus

# Deploy containers
az container create \
  --resource-group fractimewave-rg \
  --name fractimewave-backend \
  --image YOUR_REGISTRY/fractimewave-backend:latest \
  --dns-name-label fractimewave-api \
  --ports 8001

az container create \
  --resource-group fractimewave-rg \
  --name fractimewave-frontend \
  --image YOUR_REGISTRY/fractimewave-frontend:latest \
  --dns-name-label fractimewave-app \
  --ports 3000
```

---

## 🔧 Configuration

### Environment Variables

#### Backend Configuration
```bash
# Database
MONGO_URL=mongodb://localhost:27017/fractimewave_db
MONGO_USERNAME=fractimewave
MONGO_PASSWORD=secure_password

# Server
HOST=0.0.0.0
PORT=8001
ENVIRONMENT=production
DEBUG=false
LOG_LEVEL=info

# Scientific Parameters
DEFAULT_FRACTAL_DIMENSION=1.7
DEFAULT_GRAVITONIUM_COUPLING=1000.0
DEFAULT_GRAVITONIUM_MASS_SQUARED=100000000.0

# Security
SECRET_KEY=your_secure_secret_key
CORS_ORIGINS=["https://yourdomain.com"]
```

#### Frontend Configuration
```bash
# API Connection
REACT_APP_BACKEND_URL=https://api.yourdomain.com

# Application
REACT_APP_VERSION=2.0.0
REACT_APP_ENVIRONMENT=production

# Features
REACT_APP_ENABLE_ADVANCED_FEATURES=true
REACT_APP_DEFAULT_LANGUAGE=en
```

### Database Configuration

#### MongoDB Atlas (Cloud)
```bash
MONGO_URL=mongodb+srv://username:password@cluster.mongodb.net/fractimewave?retryWrites=true&w=majority
```

#### Self-hosted MongoDB
```bash
# Standard connection
MONGO_URL=mongodb://username:password@host:27017/fractimewave

# Replica set
MONGO_URL=mongodb://username:password@host1:27017,host2:27017,host3:27017/fractimewave?replicaSet=rs0
```

---

## 🔐 Security Configuration

### SSL/HTTPS Setup

#### Nginx Configuration
```nginx
server {
    listen 443 ssl http2;
    server_name yourdomain.com;
    
    ssl_certificate /etc/ssl/certs/fractimewave.crt;
    ssl_certificate_key /etc/ssl/private/fractimewave.key;
    
    # Security headers
    add_header X-Content-Type-Options nosniff;
    add_header X-Frame-Options DENY;
    add_header X-XSS-Protection "1; mode=block";
    
    location / {
        proxy_pass http://fractimewave-frontend:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
    
    location /api/ {
        proxy_pass http://fractimewave-backend:8001/api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

#### Let's Encrypt SSL
```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d yourdomain.com -d api.yourdomain.com

# Auto-renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

### Environment Security
```bash
# Generate secure random keys
openssl rand -hex 32  # For SECRET_KEY

# Use environment-specific credentials
# Never commit real credentials to git
# Use secrets management in production
```

---

## 📊 Monitoring and Logging

### Application Monitoring

#### Health Checks
```bash
# Backend health
curl https://api.yourdomain.com/api/health

# Frontend health  
curl https://yourdomain.com/health

# Database health
mongosh --eval "db.adminCommand('ping')"
```

#### Log Configuration
```python
# backend/logging_config.py
import logging
import sys

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/app/logs/fractimewave.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
```

### Performance Monitoring

#### Docker Stats
```bash
docker stats fractimewave-backend fractimewave-frontend fractimewave-mongo
```

#### System Resources
```bash
# CPU and memory usage
top -p $(pgrep -f "python server.py")
top -p $(pgrep -f "node.*react")

# Disk usage
df -h
du -sh /path/to/fractimewave/
```

---

## 🔄 Backup and Recovery

### Database Backup
```bash
# MongoDB backup
mongodump --host localhost:27017 --db fractimewave_db --out /backup/$(date +%Y%m%d)

# Restore
mongorestore --host localhost:27017 --db fractimewave_db /backup/20250107/fractimewave_db/
```

### Application Backup
```bash
# Backup script
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backup/fractimewave_$DATE"

mkdir -p $BACKUP_DIR

# Backup database
mongodump --host localhost:27017 --db fractimewave_db --out $BACKUP_DIR/db

# Backup application files
cp -r /path/to/fractimewave $BACKUP_DIR/app

# Backup configuration
cp .env $BACKUP_DIR/config.env

# Create archive
tar -czf "fractimewave_backup_$DATE.tar.gz" $BACKUP_DIR
```

---

## 🚨 Troubleshooting

### Common Issues

#### Backend Won't Start
```bash
# Check logs
tail -f backend/logs/fractimewave.log

# Check port availability
lsof -i :8001

# Verify MongoDB connection
mongosh "mongodb://localhost:27017/fractimewave_db"
```

#### Frontend Build Fails
```bash
# Clear cache
yarn cache clean
rm -rf node_modules package-lock.json yarn.lock
yarn install

# Check Node.js version
node --version  # Should be 18+
```

#### Database Connection Issues
```bash
# Test MongoDB connectivity
mongosh --eval "db.adminCommand('ping')"

# Check MongoDB logs
tail -f /var/log/mongodb/mongod.log

# Verify network connectivity
telnet localhost 27017
```

### Performance Issues

#### High CPU Usage
- Monitor scientific calculations
- Check for infinite loops in temporal analysis
- Optimize Gravitonium parameter calculations

#### Memory Leaks
- Monitor Node.js heap usage
- Check Python memory usage during simulations
- Implement calculation result caching

#### Database Performance
- Add indexes for temporal node queries
- Optimize aggregation pipelines
- Monitor slow query logs

---

## 📞 Support

### Getting Help
- **Documentation**: Check README.md and inline code comments
- **Issues**: Report bugs at https://github.com/danilo-madia/fractimewave/issues
- **Discussions**: Join community discussions on GitHub
- **Security**: Report security issues privately to maintainers

### Professional Support
For production deployments and scientific collaboration:
- Cloud architecture consultation
- Custom feature development
- Scientific accuracy validation
- Performance optimization
- Training and workshops

---

**Deployment Status Checklist:**
- [ ] Environment configured
- [ ] Database connected
- [ ] Backend responding to health checks
- [ ] Frontend loading correctly
- [ ] SSL certificates configured (production)
- [ ] Monitoring and logging active
- [ ] Backup procedures implemented
- [ ] Documentation updated

**FracTimeWave is now ready to advance multidimensional physics research!** 🌊⚛️🚀