import requests
import sys
import json
from datetime import datetime

class EnhancedFractalGravitonAPITester:
    def __init__(self, base_url="https://ae8868f0-e4a1-4c35-be15-e67d75153b4b.preview.emergentagent.com"):
        self.base_url = base_url
        self.tests_run = 0
        self.tests_passed = 0
        self.supported_languages = ['it', 'en', 'fr', 'de', 'es', 'ar', 'zh']

    def run_test(self, name, method, endpoint, expected_status, data=None, validate_response=None):
        """Run a single API test"""
        url = f"{self.base_url}/{endpoint}"
        headers = {'Content-Type': 'application/json'}

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=30)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=30)

            success = response.status_code == expected_status
            
            if success:
                try:
                    response_data = response.json()
                    print(f"✅ Passed - Status: {response.status_code}")
                    
                    # Additional validation if provided
                    if validate_response and callable(validate_response):
                        validation_result = validate_response(response_data)
                        if validation_result:
                            print(f"   ✅ Response validation passed")
                        else:
                            print(f"   ⚠️ Response validation failed")
                            success = False
                    
                    # Print key response data
                    if isinstance(response_data, dict):
                        for key, value in list(response_data.items())[:3]:  # Show first 3 keys
                            if isinstance(value, (int, float, str, bool)):
                                print(f"   📊 {key}: {value}")
                    
                except json.JSONDecodeError:
                    print(f"   ⚠️ Response is not valid JSON")
                    success = False
                    response_data = {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {error_data}")
                except:
                    print(f"   Error text: {response.text[:200]}")
                response_data = {}

            if success:
                self.tests_passed += 1
                
            return success, response_data

        except requests.exceptions.Timeout:
            print(f"❌ Failed - Request timeout (30s)")
            return False, {}
        except requests.exceptions.ConnectionError:
            print(f"❌ Failed - Connection error")
            return False, {}
        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    # ENHANCED v2.0.0 TESTS

    def test_health_check_multilang(self):
        """Test health check endpoint with multi-language support"""
        def validate_health(data):
            has_status = 'status' in data
            has_theory = 'theory' in data
            has_author = data.get('author') == 'Danilo Madia'
            has_version = data.get('version') == '2.0.0 Enhanced'
            has_features = isinstance(data.get('features'), list) and len(data.get('features', [])) >= 5
            
            print(f"   🏥 Status: {data.get('status')}")
            print(f"   👨‍🔬 Author: {data.get('author')}")
            print(f"   🔢 Version: {data.get('version')}")
            print(f"   ✨ Features: {len(data.get('features', []))}")
            
            return has_status and has_theory and has_author and has_version and has_features
        
        return self.run_test(
            "Enhanced Health Check (Italian)",
            "GET",
            "api/health?language=it",
            200,
            validate_response=validate_health
        )

    def test_supported_languages(self):
        """Test supported languages endpoint"""
        def validate_languages(data):
            languages = data.get('supported_languages', [])
            has_all_languages = len(languages) == 7
            has_italian = any(lang.get('code') == 'it' for lang in languages)
            has_english = any(lang.get('code') == 'en' for lang in languages)
            has_chinese = any(lang.get('code') == 'zh' for lang in languages)
            
            print(f"   🌍 Total languages: {len(languages)}")
            for lang in languages[:3]:  # Show first 3
                print(f"   🗣️ {lang.get('code')}: {lang.get('native')}")
            
            return has_all_languages and has_italian and has_english and has_chinese
        
        return self.run_test(
            "Supported Languages",
            "GET",
            "api/supported-languages",
            200,
            validate_response=validate_languages
        )

    def test_enhanced_gravitational_simulation(self):
        """Test enhanced gravitational wave simulation with Gravitonium parameters"""
        simulation_params = {
            "r": 100.0,
            "time_steps": 1000,
            "time_max": 1e-6,
            "D_10f": 1.7,
            "amplitude_scale": 1e-5,
            "gravitonium_coupling": 1000.0,  # g_g ≈ 10³
            "gravitonium_mass_squared": 1e8   # m² ≈ 10⁸ eV²
        }
        
        def validate_enhanced_simulation(data):
            has_gravitonium_factor = 'gravitonium_factor' in data
            has_gravitonium_efficiency = 'gravitonium_efficiency' in data
            has_optimization_status = 'optimization_status' in data
            has_h_10_harmonic = 'h_10_harmonic' in data
            has_simulation_id = 'simulation_id' in data
            
            g_factor = data.get('gravitonium_factor', 0)
            g_efficiency = data.get('gravitonium_efficiency', 0)
            h_10 = data.get('h_10_harmonic', 0)
            
            print(f"   🔬 Gravitonium factor: {g_factor:.2e}")
            print(f"   ⚡ Gravitonium efficiency: {g_efficiency:.2e}")
            print(f"   📈 H_10 harmonic: {h_10:.2e}")
            print(f"   🎯 Optimization: {data.get('optimization_status', 'N/A')}")
            
            return (has_gravitonium_factor and has_gravitonium_efficiency and 
                   has_optimization_status and has_h_10_harmonic and has_simulation_id)
        
        return self.run_test(
            "Enhanced Gravitational Simulation (Gravitonium)",
            "POST",
            "api/simulate-gravitational-waves-enhanced",
            200,
            data=simulation_params,
            validate_response=validate_enhanced_simulation
        )

    def test_enhanced_temporal_node_prediction(self):
        """Test enhanced temporal node prediction with multi-language support"""
        node_params = {
            "date_string": "2025-12-27",
            "language": "en"
        }
        
        def validate_enhanced_node(data):
            node_analysis = data.get('node_analysis', {})
            has_status_message = 'status_message' in node_analysis
            has_readable_date = 'readable_date' in node_analysis
            is_temporal_node = node_analysis.get('is_temporal_node', False)
            
            print(f"   🎯 Is temporal node: {is_temporal_node}")
            print(f"   💬 Status message: {node_analysis.get('status_message', 'N/A')}")
            print(f"   📅 Readable date: {node_analysis.get('readable_date', 'N/A')}")
            print(f"   🔢 Hamming weight: {node_analysis.get('hamming_weight', 0)}/64")
            
            return has_status_message and has_readable_date and is_temporal_node
        
        return self.run_test(
            "Enhanced Temporal Node Prediction (Multi-lang)",
            "POST",
            "api/predict-temporal-node-enhanced",
            200,
            data=node_params,
            validate_response=validate_enhanced_node
        )

    def test_historical_events(self):
        """Test historical events endpoint"""
        event_query = {
            "date": "2025-12-27",
            "language": "en"
        }
        
        def validate_historical_events(data):
            has_date = 'date' in data
            has_events = 'events' in data
            has_language = 'language' in data
            events_list = data.get('events', [])
            
            print(f"   📅 Date: {data.get('date')}")
            print(f"   🌍 Language: {data.get('language')}")
            print(f"   📋 Events found: {len(events_list)}")
            
            if events_list:
                for event in events_list[:2]:  # Show first 2
                    print(f"   📖 Event: {event.get('title', 'N/A')}")
            
            return has_date and has_events and has_language
        
        return self.run_test(
            "Historical Events",
            "POST",
            "api/historical-events",
            200,
            data=event_query,
            validate_response=validate_historical_events
        )

    def test_faq_chatbox(self):
        """Test FAQ ChatBox functionality"""
        chat_message = {
            "message": "What is FGT?",
            "language": "en",
            "session_id": "test_session_123"
        }
        
        def validate_chatbox(data):
            has_response = 'response' in data and len(data.get('response', '')) > 0
            has_language = 'language' in data
            has_type = data.get('type') == 'faq'
            has_note = 'note' in data
            
            print(f"   💬 Response length: {len(data.get('response', ''))}")
            print(f"   🌍 Language: {data.get('language')}")
            print(f"   🏷️ Type: {data.get('type')}")
            print(f"   📝 Note: {data.get('note', 'N/A')[:50]}...")
            
            return has_response and has_language and has_type and has_note
        
        return self.run_test(
            "FAQ ChatBox",
            "POST",
            "api/faq-chatbox",
            200,
            data=chat_message,
            validate_response=validate_chatbox
        )

    def test_daily_research_monitoring(self):
        """Test daily research monitoring with binary encoding"""
        research_entry = {
            "research_query": "Testing Gravitonium field optimization parameters"
        }
        
        def validate_research_monitoring(data):
            has_date = 'date' in data
            has_binary_encoding = 'binary_encoding' in data and len(data.get('binary_encoding', '')) == 64
            has_hamming_weight = 'hamming_weight' in data
            has_hamming_distance = 'hamming_distance' in data
            has_status = 'status' in data
            
            binary_code = data.get('binary_encoding', '')
            hamming_weight = data.get('hamming_weight', 0)
            
            print(f"   📅 Date: {data.get('date')}")
            print(f"   🔢 Binary length: {len(binary_code)}")
            print(f"   ⚖️ Hamming weight: {hamming_weight}/64")
            print(f"   📏 Hamming distance: {data.get('hamming_distance', 0)}")
            print(f"   ✅ Status: {data.get('status', 'N/A')}")
            
            return (has_date and has_binary_encoding and has_hamming_weight and 
                   has_hamming_distance and has_status and hamming_weight <= 64)
        
        return self.run_test(
            "Daily Research Monitoring",
            "POST",
            "api/daily-research-monitoring",
            200,
            data=research_entry,
            validate_response=validate_research_monitoring
        )

    def test_daily_research_history(self):
        """Test daily research history endpoint"""
        def validate_research_history(data):
            has_history = 'history' in data
            has_total_entries = 'total_entries' in data
            history_list = data.get('history', [])
            
            print(f"   📋 Total entries: {data.get('total_entries', 0)}")
            print(f"   📊 History length: {len(history_list)}")
            
            if history_list:
                entry = history_list[0]
                print(f"   📝 Latest query: {entry.get('research_query', 'N/A')[:50]}...")
                print(f"   🔢 Binary encoding: {entry.get('binary_encoding', 'N/A')[:20]}...")
            
            return has_history and has_total_entries
        
        return self.run_test(
            "Daily Research History",
            "GET",
            "api/daily-research-history?days=30",
            200,
            validate_response=validate_research_history
        )

    def test_multilang_health_checks(self):
        """Test health check in multiple languages"""
        test_results = []
        
        for lang in ['it', 'en', 'fr', 'de']:  # Test 4 languages
            def validate_lang_health(data):
                return 'status' in data and 'theory' in data
            
            success, _ = self.run_test(
                f"Health Check ({lang.upper()})",
                "GET",
                f"api/health?language={lang}",
                200,
                validate_response=validate_lang_health
            )
            test_results.append(success)
        
        return all(test_results), {}

    def test_known_temporal_nodes_multilang(self):
        """Test known temporal nodes with language support"""
        def validate_multilang_nodes(data):
            known_nodes = data.get('known_nodes', [])
            has_nodes = len(known_nodes) > 0
            
            if has_nodes:
                print(f"   📋 Found {len(known_nodes)} known nodes")
                for i, node in enumerate(known_nodes[:2]):  # Show first 2
                    print(f"   📅 Node {i+1}: {node.get('date', 'N/A')} - {node.get('description', 'N/A')}")
                    if 'analysis' in node:
                        print(f"   🎯 Is temporal: {node['analysis'].get('is_temporal_node', False)}")
            
            return has_nodes
        
        return self.run_test(
            "Known Temporal Nodes (Multi-lang)",
            "GET",
            "api/known-temporal-nodes?language=en",
            200,
            validate_response=validate_multilang_nodes
        )

def main():
    print("🚀 Starting Enhanced Fractal Graviton Theory API Tests v2.0.0")
    print("=" * 70)
    
    tester = EnhancedFractalGravitonAPITester()
    
    # Run all enhanced tests
    test_results = []
    
    # Enhanced v2.0.0 features
    print("\n🌟 ENHANCED v2.0.0 FEATURES TESTING")
    print("-" * 50)
    
    success, _ = tester.test_health_check_multilang()
    test_results.append(("Enhanced Health Check", success))
    
    success, _ = tester.test_supported_languages()
    test_results.append(("Supported Languages", success))
    
    success, _ = tester.test_enhanced_gravitational_simulation()
    test_results.append(("Enhanced Gravitational Simulation", success))
    
    success, _ = tester.test_enhanced_temporal_node_prediction()
    test_results.append(("Enhanced Temporal Node Prediction", success))
    
    success, _ = tester.test_historical_events()
    test_results.append(("Historical Events", success))
    
    success, _ = tester.test_faq_chatbox()
    test_results.append(("FAQ ChatBox", success))
    
    success, _ = tester.test_daily_research_monitoring()
    test_results.append(("Daily Research Monitoring", success))
    
    success, _ = tester.test_daily_research_history()
    test_results.append(("Daily Research History", success))
    
    success, _ = tester.test_multilang_health_checks()
    test_results.append(("Multi-language Health Checks", success))
    
    success, _ = tester.test_known_temporal_nodes_multilang()
    test_results.append(("Known Temporal Nodes Multi-lang", success))
    
    # Print final results
    print("\n" + "=" * 70)
    print("📊 ENHANCED v2.0.0 TEST RESULTS")
    print("=" * 70)
    
    for test_name, success in test_results:
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}")
    
    print(f"\n📈 Overall: {tester.tests_passed}/{tester.tests_run} tests passed")
    
    # Enhanced success criteria
    critical_features = [
        "Enhanced Health Check",
        "Supported Languages", 
        "Enhanced Gravitational Simulation",
        "FAQ ChatBox",
        "Daily Research Monitoring"
    ]
    
    critical_passed = sum(1 for name, success in test_results if name in critical_features and success)
    
    print(f"🎯 Critical features: {critical_passed}/{len(critical_features)} passed")
    
    if tester.tests_passed == tester.tests_run:
        print("🎉 All enhanced v2.0.0 tests passed! Backend API is fully functional.")
        return 0
    elif critical_passed == len(critical_features):
        print("✅ All critical enhanced features working. Minor issues detected.")
        return 0
    else:
        print("⚠️ Some critical enhanced features failed. Check the details above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())