import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Slider } from './components/ui/slider';
import { Badge } from './components/ui/badge';
import { Alert, AlertDescription } from './components/ui/alert';
import { Separator } from './components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  ReferenceLine
} from 'recharts';
import { 
  Atom, 
  Zap, 
  Clock, 
  Binary, 
  Calculator, 
  Microscope, 
  Waves,
  TrendingUp,
  BookOpen,
  Github,
  Mail,
  Globe,
  MessageSquare,
  History,
  Search,
  Calendar,
  Database
} from 'lucide-react';
import './App.css';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

function App() {
  // Enhanced state management
  const [activeTab, setActiveTab] = useState('simulation');
  const [currentLanguage, setCurrentLanguage] = useState('it');
  const [supportedLanguages, setSupportedLanguages] = useState([]);
  
  // Simulation states
  const [simulationParams, setSimulationParams] = useState({
    r: 100,
    time_steps: 1000,
    time_max: 0.000001,
    D_10f: 1.7,
    amplitude_scale: 0.00001,
    gravitonium_coupling: 1000.0,
    gravitonium_mass_squared: 1e8
  });
  const [simulationData, setSimulationData] = useState(null);
  const [isSimulating, setIsSimulating] = useState(false);
  
  // Temporal node states
  const [nodeParams, setNodeParams] = useState({
    timestamp: null,
    date_string: '2025-12-27',
    language: 'it'
  });
  const [nodeAnalysis, setNodeAnalysis] = useState(null);
  const [knownNodes, setKnownNodes] = useState([]);
  const [fractalStats, setFractalStats] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // Historical events states
  const [historicalDate, setHistoricalDate] = useState('2025-12-27');
  const [historicalEvents, setHistoricalEvents] = useState([]);
  const [isLoadingEvents, setIsLoadingEvents] = useState(false);
  
  // ChatBox states
  const [chatMessage, setChatMessage] = useState('');
  const [chatHistory, setChatHistory] = useState([]);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [chatSessionId] = useState(`session_${Date.now()}`);
  
  // Research monitoring states
  const [researchQuery, setResearchQuery] = useState('');
  const [researchHistory, setResearchHistory] = useState([]);
  const [isResearchLoading, setIsResearchLoading] = useState(false);

  // Language translations
  const [translations, setTranslations] = useState({});

  // Load supported languages on mount
  useEffect(() => {
    fetchSupportedLanguages();
    fetchKnownNodes();
    fetchFractalStatistics(simulationParams.r);
    fetchResearchHistory();
  }, []);

  // Update language-dependent data when language changes
  useEffect(() => {
    setNodeParams(prev => ({ ...prev, language: currentLanguage }));
    fetchKnownNodes();
    fetchFractalStatistics(simulationParams.r);
  }, [currentLanguage]);

  const fetchSupportedLanguages = async () => {
    try {
      const response = await fetch(`${BACKEND_URL}/api/supported-languages`);
      const data = await response.json();
      setSupportedLanguages(data.supported_languages || []);
    } catch (error) {
      console.error('Failed to fetch supported languages:', error);
    }
  };

  const fetchKnownNodes = async () => {
    try {
      const response = await fetch(`${BACKEND_URL}/api/known-temporal-nodes?language=${currentLanguage}`);
      const data = await response.json();
      setKnownNodes(data.known_nodes || []);
    } catch (error) {
      console.error('Failed to fetch known nodes:', error);
    }
  };

  const fetchFractalStatistics = async (r) => {
    try {
      const response = await fetch(`${BACKEND_URL}/api/fractal-statistics/${r}?language=${currentLanguage}`);
      const data = await response.json();
      setFractalStats(data);
    } catch (error) {
      console.error('Failed to fetch fractal statistics:', error);
    }
  };

  const fetchResearchHistory = async () => {
    try {
      const response = await fetch(`${BACKEND_URL}/api/daily-research-history?days=30`);
      const data = await response.json();
      setResearchHistory(data.history || []);
    } catch (error) {
      console.error('Failed to fetch research history:', error);
    }
  };

  const runEnhancedGravitationalSimulation = async () => {
    setIsSimulating(true);
    try {
      const response = await fetch(`${BACKEND_URL}/api/simulate-gravitational-waves-enhanced`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(simulationParams)
      });
      const result = await response.json();
      
      // Format data for chart
      const chartData = result.time_array.map((time, index) => ({
        time: time * 1e6, // Convert to microseconds
        g_00: result.g_00_values[index],
        time_seconds: time
      }));
      
      setSimulationData({
        ...result,
        chartData
      });
      
      // Update fractal statistics
      fetchFractalStatistics(simulationParams.r);
      
    } catch (error) {
      console.error('Enhanced simulation failed:', error);
    } finally {
      setIsSimulating(false);
    }
  };

  const predictTemporalNode = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`${BACKEND_URL}/api/predict-temporal-node-enhanced`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...nodeParams,
          language: currentLanguage
        })
      });
      const result = await response.json();
      setNodeAnalysis(result.node_analysis);
    } catch (error) {
      console.error('Node prediction failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const searchHistoricalEvents = async () => {
    setIsLoadingEvents(true);
    try {
      const response = await fetch(`${BACKEND_URL}/api/historical-events`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: historicalDate,
          language: currentLanguage
        })
      });
      const result = await response.json();
      setHistoricalEvents(result.events || []);
    } catch (error) {
      console.error('Historical events search failed:', error);
    } finally {
      setIsLoadingEvents(false);
    }
  };

  const sendChatMessage = async () => {
    if (!chatMessage.trim()) return;
    
    setIsChatLoading(true);
    const userMessage = chatMessage;
    
    // Add user message to history
    setChatHistory(prev => [...prev, {
      type: 'user',
      message: userMessage,
      timestamp: new Date().toLocaleTimeString()
    }]);
    
    setChatMessage('');
    
    try {
      const response = await fetch(`${BACKEND_URL}/api/faq-chatbox`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage,
          language: currentLanguage,
          session_id: chatSessionId
        })
      });
      const result = await response.json();
      
      // Add bot response to history
      setChatHistory(prev => [...prev, {
        type: 'bot',
        message: result.response,
        timestamp: new Date().toLocaleTimeString(),
        note: result.note
      }]);
      
    } catch (error) {
      console.error('Chat message failed:', error);
      setChatHistory(prev => [...prev, {
        type: 'bot',
        message: 'Errore di connessione. Riprova.',
        timestamp: new Date().toLocaleTimeString()
      }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  const submitResearchMonitoring = async () => {
    if (!researchQuery.trim()) return;
    
    setIsResearchLoading(true);
    try {
      const response = await fetch(`${BACKEND_URL}/api/daily-research-monitoring`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          research_query: researchQuery
        })
      });
      const result = await response.json();
      
      // Refresh research history
      fetchResearchHistory();
      setResearchQuery('');
      
    } catch (error) {
      console.error('Research monitoring failed:', error);
    } finally {
      setIsResearchLoading(false);
    }
  };

  const formatScientific = (value) => {
    if (Math.abs(value) < 0.001 || Math.abs(value) >= 1000) {
      return value.toExponential(3);
    }
    return value.toFixed(6);
  };

  const getLanguageText = (key, fallback = '') => {
    const langTexts = {
      'it': {
        'app_title': 'FracTimeWave',
        'app_subtitle': 'Sistema_Cronobinario • Danilo Madia',
        'simulation_tab': 'Simulazione',
        'cronobinary_tab': 'Cronobinario',
        'education_tab': 'Educazione',
        'collaboration_tab': 'Collabora',
        'chatbox_tab': 'ChatBox',
        'research_tab': 'Ricerca',
        'simulate_waves': 'Simula Onde Gravitazionali',
        'analyzing': 'Analizzando...',
        'analyze_node': 'Analizza Nodo Temporale',
        'send_message': 'Invia Messaggio',
        'search_events': 'Cerca Eventi',
        'submit_research': 'Registra Ricerca'
      },
      'en': {
        'app_title': 'FracTimeWave',
        'app_subtitle': 'Cronobinary System • Danilo Madia',
        'simulation_tab': 'Simulation',
        'cronobinary_tab': 'Cronobinary',
        'education_tab': 'Education',
        'collaboration_tab': 'Collaborate',
        'chatbox_tab': 'ChatBox',
        'research_tab': 'Research',
        'simulate_waves': 'Simulate Gravitational Waves',
        'analyzing': 'Analyzing...',
        'analyze_node': 'Analyze Temporal Node',
        'send_message': 'Send Message',
        'search_events': 'Search Events',
        'submit_research': 'Submit Research'
      },
      'fr': {
        'app_title': 'FracTimeWave',
        'app_subtitle': 'Système Cronobinaire • Danilo Madia',
        'simulation_tab': 'Simulation',
        'cronobinary_tab': 'Cronobinaire',
        'education_tab': 'Éducation',
        'collaboration_tab': 'Collaborer',
        'chatbox_tab': 'ChatBox',
        'research_tab': 'Recherche',
        'simulate_waves': 'Simuler les Ondes Gravitationnelles',
        'analyzing': 'Analyse...',
        'analyze_node': 'Analyser le Nœud Temporel',
        'send_message': 'Envoyer Message',
        'search_events': 'Rechercher Événements',
        'submit_research': 'Soumettre Recherche'
      }
    };
    
    return langTexts[currentLanguage]?.[key] || langTexts['en']?.[key] || fallback;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Enhanced Header */}
      <header className="border-b border-slate-700/50 bg-slate-900/80 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Waves className="w-8 h-8 text-purple-400" />
              <div>
                <h1 className="text-2xl font-bold text-white">{getLanguageText('app_title')}</h1>
                <p className="text-sm text-slate-400">{getLanguageText('app_subtitle')}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              {/* Language Selector */}
              <Select value={currentLanguage} onValueChange={setCurrentLanguage}>
                <SelectTrigger className="w-32 bg-slate-800 border-slate-600">
                  <Globe className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {supportedLanguages.map(lang => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.native}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Badge variant="secondary" className="bg-purple-600/20 text-purple-300">
                FGT Enhanced
              </Badge>
              <Badge variant="secondary" className="bg-green-600/20 text-green-300">
                v2.0.0
              </Badge>
              <Badge variant="secondary" className="bg-blue-600/20 text-blue-300">
                MIT License
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Enhanced Main Content */}
      <main className="container mx-auto px-6 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid grid-cols-6 w-full max-w-2xl mx-auto bg-slate-800/50">
            <TabsTrigger value="simulation" className="flex items-center space-x-2">
              <Waves className="w-4 h-4" />
              <span>{getLanguageText('simulation_tab')}</span>
            </TabsTrigger>
            <TabsTrigger value="cronobinary" className="flex items-center space-x-2">
              <Clock className="w-4 h-4" />
              <span>{getLanguageText('cronobinary_tab')}</span>
            </TabsTrigger>
            <TabsTrigger value="education" className="flex items-center space-x-2">
              <BookOpen className="w-4 h-4" />
              <span>{getLanguageText('education_tab')}</span>
            </TabsTrigger>
            <TabsTrigger value="chatbox" className="flex items-center space-x-2">
              <MessageSquare className="w-4 h-4" />
              <span>ChatBox</span>
            </TabsTrigger>
            <TabsTrigger value="research" className="flex items-center space-x-2">
              <Database className="w-4 h-4" />
              <span>{getLanguageText('research_tab')}</span>
            </TabsTrigger>
            <TabsTrigger value="collaboration" className="flex items-center space-x-2">
              <Microscope className="w-4 h-4" />
              <span>{getLanguageText('collaboration_tab')}</span>
            </TabsTrigger>
          </TabsList>

          {/* Enhanced Fractal Gravitational Wave Simulation */}
          <TabsContent value="simulation" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Enhanced Parameter Controls */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white">
                    <Calculator className="w-5 h-5" />
                    <span>FracTimeWave Parameters</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-slate-300">Spatial Scale (r)</Label>
                    <Slider
                      value={[simulationParams.r]}
                      onValueChange={([value]) => setSimulationParams({...simulationParams, r: value})}
                      max={1000}
                      min={1}
                      step={1}
                      className="mt-2"
                    />
                    <span className="text-sm text-slate-400">{simulationParams.r}</span>
                  </div>

                  <div>
                    <Label className="text-slate-300">Fractal Dimension (D₁₀,f)</Label>
                    <Slider
                      value={[simulationParams.D_10f]}
                      onValueChange={([value]) => setSimulationParams({...simulationParams, D_10f: value})}
                      max={3}
                      min={1}
                      step={0.1}
                      className="mt-2"
                    />
                    <span className="text-sm text-slate-400">{simulationParams.D_10f}</span>
                  </div>

                  <div>
                    <Label className="text-slate-300">Gravitonium Coupling (g_g)</Label>
                    <Slider
                      value={[simulationParams.gravitonium_coupling]}
                      onValueChange={([value]) => setSimulationParams({...simulationParams, gravitonium_coupling: value})}
                      max={1050}
                      min={950}
                      step={10}
                      className="mt-2"
                    />
                    <span className="text-sm text-slate-400">{simulationParams.gravitonium_coupling} (±5%)</span>
                  </div>

                  <div>
                    <Label className="text-slate-300">Mass² (10⁸ eV²)</Label>
                    <Slider
                      value={[simulationParams.gravitonium_mass_squared / 1e8]}
                      onValueChange={([value]) => setSimulationParams({...simulationParams, gravitonium_mass_squared: value * 1e8})}
                      max={1.05}
                      min={0.95}
                      step={0.01}
                      className="mt-2"
                    />
                    <span className="text-sm text-slate-400">{(simulationParams.gravitonium_mass_squared / 1e8).toFixed(2)} (±5%)</span>
                  </div>

                  <Button 
                    onClick={runEnhancedGravitationalSimulation}
                    disabled={isSimulating}
                    className="w-full bg-purple-600 hover:bg-purple-700"
                  >
                    {isSimulating ? (
                      <>
                        <Zap className="w-4 h-4 mr-2 animate-spin" />
                        {getLanguageText('analyzing')}
                      </>
                    ) : (
                      <>
                        <Waves className="w-4 h-4 mr-2" />
                        {getLanguageText('simulate_waves')}
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Enhanced Visualization */}
              <Card className="lg:col-span-2 bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">FracTimeWave Metric Tensor g₀₀(t) with Gravitonium Field</CardTitle>
                </CardHeader>
                <CardContent>
                  {simulationData ? (
                    <div className="space-y-4">
                      <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={simulationData.chartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                          <XAxis 
                            dataKey="time" 
                            stroke="#94a3b8"
                            label={{ value: 'Time (µs)', position: 'insideBottom', offset: -10, fill: '#94a3b8' }}
                          />
                          <YAxis 
                            stroke="#94a3b8"
                            tickFormatter={formatScientific}
                            label={{ value: 'g₀₀', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
                          />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: '#1e293b', 
                              border: '1px solid #475569',
                              borderRadius: '8px'
                            }}
                            formatter={(value) => [formatScientific(value), 'g₀₀']}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="g_00" 
                            stroke="#a855f7" 
                            strokeWidth={2}
                            dot={false}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                      
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div className="bg-slate-700/50 p-3 rounded">
                          <Label className="text-slate-400">H₁₀ Harmonic</Label>
                          <p className="text-white font-mono">{formatScientific(simulationData.h_10_harmonic)}</p>
                        </div>
                        <div className="bg-slate-700/50 p-3 rounded">
                          <Label className="text-slate-400">Gravitonium Factor</Label>
                          <p className="text-white font-mono">{formatScientific(simulationData.gravitonium_factor)}</p>
                        </div>
                        <div className="bg-slate-700/50 p-3 rounded">
                          <Label className="text-slate-400">Efficiency</Label>
                          <p className="text-white font-mono">{formatScientific(simulationData.gravitonium_efficiency)}</p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="h-300 flex items-center justify-center text-slate-400">
                      <div className="text-center">
                        <Waves className="w-16 h-16 mx-auto mb-4 opacity-50" />
                        <p>Run FracTimeWave simulation to visualize Gravitonium-modulated gravitational waves</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Enhanced Fractal Statistics */}
            {fractalStats && (
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white">
                    <TrendingUp className="w-5 h-5" />
                    <span>FracTimeWave Statistics</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-slate-700/50 p-4 rounded">
                      <Label className="text-slate-400">N(r) ∝ r^(D₁₀,f - 3)</Label>
                      <p className="text-2xl font-bold text-purple-400">
                        {formatScientific(fractalStats.N_r_scaling)}
                      </p>
                    </div>
                    <div className="bg-slate-700/50 p-4 rounded">
                      <Label className="text-slate-400">ΔT ∝ r^(D₁₀,f - 2)</Label>
                      <p className="text-2xl font-bold text-blue-400">
                        {formatScientific(fractalStats.delta_T_scaling)}
                      </p>
                    </div>
                    <div className="bg-slate-700/50 p-4 rounded">
                      <Label className="text-slate-400">Fractal Dimension</Label>
                      <p className="text-2xl font-bold text-green-400">
                        {fractalStats.fractal_dimension}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Enhanced Sistema Cronobinario */}
          <TabsContent value="cronobinary" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Enhanced Temporal Node Prediction */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white">
                    <Binary className="w-5 h-5" />
                    <span>FracTimeWave Temporal Analysis</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-slate-300">Date (YYYY-MM-DD)</Label>
                    <Input
                      value={nodeParams.date_string}
                      onChange={(e) => setNodeParams({...nodeParams, date_string: e.target.value})}
                      className="bg-slate-700 border-slate-600 text-white"
                      placeholder="2025-12-27"
                    />
                  </div>

                  <Button 
                    onClick={predictTemporalNode}
                    disabled={isLoading}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    {isLoading ? (
                      <>
                        <Clock className="w-4 h-4 mr-2 animate-spin" />
                        {getLanguageText('analyzing')}
                      </>
                    ) : (
                      <>
                        <Binary className="w-4 h-4 mr-2" />
                        {getLanguageText('analyze_node')}
                      </>
                    )}
                  </Button>

                  {nodeAnalysis && (
                    <div className="space-y-3 mt-4">
                      <Alert className={`${nodeAnalysis.is_temporal_node ? 'border-green-500' : 'border-yellow-500'}`}>
                        <Clock className="w-4 h-4" />
                        <AlertDescription>
                          {nodeAnalysis.status_message || (nodeAnalysis.is_temporal_node 
                            ? '🎯 Nodo temporale rilevato!' 
                            : '⚠️ Nodo temporale debole')}
                        </AlertDescription>
                      </Alert>

                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div className="bg-slate-700/50 p-3 rounded">
                          <Label className="text-slate-400">H₁₀ Harmonic</Label>
                          <p className="text-white font-mono">{formatScientific(nodeAnalysis.H_10_harmonic)}</p>
                        </div>
                        <div className="bg-slate-700/50 p-3 rounded">
                          <Label className="text-slate-400">Node Strength</Label>
                          <p className="text-white font-mono">{formatScientific(nodeAnalysis.node_strength)}</p>
                        </div>
                        <div className="bg-slate-700/50 p-3 rounded">
                          <Label className="text-slate-400">Hamming Weight</Label>
                          <p className="text-white font-mono">{nodeAnalysis.hamming_weight}/64</p>
                        </div>
                        <div className="bg-slate-700/50 p-3 rounded">
                          <Label className="text-slate-400">Shannon Entropy</Label>
                          <p className="text-white font-mono">{nodeAnalysis.shannon_entropy ? nodeAnalysis.shannon_entropy.toFixed(4) : '0.0000'}</p>
                        </div>
                      </div>

                      <div className="bg-slate-700/50 p-3 rounded">
                        <Label className="text-slate-400">64-bit Binary Encoding</Label>
                        <p className="text-xs font-mono text-green-400 break-all mt-1">
                          {nodeAnalysis.binary_code}
                        </p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Historical Events Integration */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white">
                    <History className="w-5 h-5" />
                    <span>Historical Events Correlation</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-slate-300">Search Date</Label>
                    <div className="flex space-x-2">
                      <Input
                        value={historicalDate}
                        onChange={(e) => setHistoricalDate(e.target.value)}
                        className="bg-slate-700 border-slate-600 text-white"
                        placeholder="YYYY-MM-DD"
                      />
                      <Button 
                        onClick={searchHistoricalEvents}
                        disabled={isLoadingEvents}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        {isLoadingEvents ? (
                          <Search className="w-4 h-4 animate-spin" />
                        ) : (
                          <Search className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {historicalEvents.map((event, index) => (
                      <div key={index} className="bg-slate-700/50 p-3 rounded">
                        <h4 className="font-semibold text-white">{event.title}</h4>
                        <p className="text-sm text-slate-400">{event.date}</p>
                        <ul className="text-xs text-slate-300 mt-1">
                          {event.events.map((item, i) => (
                            <li key={i}>• {item}</li>
                          ))}
                        </ul>
                        <Badge variant="outline" className="mt-2 text-xs">
                          {event.source}
                        </Badge>
                      </div>
                    ))}
                  </div>

                  {/* Known Temporal Nodes */}
                  <Separator className="bg-slate-600" />
                  <div className="space-y-3">
                    <h4 className="text-white font-medium">Known Temporal Nodes</h4>
                    {knownNodes && knownNodes.length > 0 ? knownNodes.map((node, index) => (
                      <div key={index} className="bg-slate-700/50 p-4 rounded">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-semibold text-white">{node.date}</p>
                            <p className="text-sm text-slate-400">{node.description}</p>
                          </div>
                          <Badge 
                            variant={node.analysis && node.analysis.is_temporal_node ? "default" : "secondary"}
                            className={node.analysis && node.analysis.is_temporal_node ? "bg-green-600" : "bg-yellow-600"}
                          >
                            {node.significance}
                          </Badge>
                        </div>
                        <div className="text-xs space-y-1">
                          <p className="text-slate-400">H₁₀: {node.analysis ? formatScientific(node.analysis.H_10_harmonic) : 'N/A'}</p>
                          <p className="text-slate-400">Entropy: {node.analysis && node.analysis.shannon_entropy ? node.analysis.shannon_entropy.toFixed(3) : 'N/A'}</p>
                        </div>
                      </div>
                    )) : (
                      <p className="text-slate-400">Loading temporal nodes...</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Enhanced Educational Content */}
          <TabsContent value="education" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">FracTimeWave - Fractal Graviton Theory</CardTitle>
                </CardHeader>
                <CardContent className="prose prose-slate prose-invert max-w-none">
                  <p className="text-slate-300 leading-relaxed">
                    <strong>FracTimeWave</strong> implements Danilo Madia's revolutionary 
                    Fractal Graviton Theory (FGT) with enhanced Gravitonium field optimization 
                    and multi-dimensional temporal analysis.
                  </p>
                  
                  <h4 className="text-purple-400 mt-4 mb-2">Core Principles</h4>
                  <div className="bg-slate-900 p-4 rounded font-mono text-sm">
                    <p className="text-green-400">g<sub>mn</sub><sup>E8,H</sup> = η<sub>mn</sub>(1 + A<sub>f</sub>r<sup>-D<sub>10,f</sub></sup>)H<sub>10</sub>(r,t)G<sub>g</sub>(r)</p>
                    <p className="text-blue-400 mt-2">G<sub>g</sub>(r) = g<sub>g</sub>/(m² + r²) (Gravitonium factor)</p>
                    <p className="text-yellow-400 mt-2">D₁₀,f = 1.7 (fractal dimension)</p>
                  </div>
                  
                  <h4 className="text-purple-400 mt-4 mb-2">FracTimeWave Features</h4>
                  <ul className="text-slate-300 space-y-1">
                    <li>• Multi-language support (7 languages)</li>
                    <li>• Historical event correlation analysis</li>
                    <li>• Gravitonium field optimization</li>
                    <li>• Daily research pattern monitoring</li>
                    <li>• Interactive FAQ system</li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Sistema Cronobinario Enhanced</CardTitle>
                </CardHeader>
                <CardContent className="prose prose-slate prose-invert max-w-none">
                  <p className="text-slate-300 leading-relaxed">
                    The enhanced <strong>Sistema_Cronobinario</strong> in FracTimeWave provides 
                    advanced temporal analysis with binary encoding and historical correlation.
                  </p>
                  
                  <h4 className="text-blue-400 mt-4 mb-2">Temporal Analysis</h4>
                  <div className="space-y-2 text-slate-300">
                    <p>1. <strong>SHA-256 Encoding:</strong> 64-bit temporal signatures</p>
                    <p>2. <strong>Hamming Analysis:</strong> Pattern detection and distance calculations</p>
                    <p>3. <strong>Historical Correlation:</strong> Event timeline synchronization</p>
                    <p>4. <strong>Shannon Entropy:</strong> Information content measurement</p>
                  </div>
                  
                  <h4 className="text-blue-400 mt-4 mb-2">Predicted Nodes</h4>
                  <div className="bg-slate-900 p-4 rounded">
                    <p className="text-green-400 font-mono">27/12/2025 - Major Temporal Node</p>
                    <p className="text-sm text-slate-400 mt-1">
                      High probability transition point with Shannon entropy: 0.696
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* FracTimeWave Theory Section */}
            <Card className="bg-gradient-to-r from-purple-900/20 to-blue-900/20 border-purple-700/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Waves className="w-6 h-6 text-purple-400" />
                  <span>FracTimeWave Theory & Applications</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="prose prose-slate prose-invert max-w-none">
                <p className="text-slate-300 leading-relaxed">
                  FracTimeWave represents the cutting-edge implementation of theoretical physics 
                  concepts, bridging quantum mechanics with fractal geometry and temporal analysis. 
                  The application enables researchers to explore multidimensional spacetime through 
                  interactive simulations and predictive modeling.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div className="bg-slate-800/50 p-4 rounded">
                    <h5 className="text-purple-400 mb-2">Gravitonium Optimization</h5>
                    <p className="text-sm text-slate-300">
                      Advanced field coupling with g_g ≈ 10³ and m² ≈ 10⁸ eV² parameters, 
                      enabling precise gravitational wave simulations at unprecedented accuracy.
                    </p>
                  </div>
                  <div className="bg-slate-800/50 p-4 rounded">
                    <h5 className="text-blue-400 mb-2">Multi-Dimensional Analysis</h5>
                    <p className="text-sm text-slate-300">
                      10D+1 spacetime modeling with fractal dimension D₁₀,f = 1.7, 
                      providing insights into cosmic structure formation and temporal patterns.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Interactive ChatBox Tab */}
          <TabsContent value="chatbox" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-white">
                  <MessageSquare className="w-5 h-5" />
                  <span>FracTimeWave AI Assistant</span>
                  <Badge variant="outline" className="text-xs">FAQ Mode</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Chat History */}
                <div className="h-64 overflow-y-auto bg-slate-900/50 p-4 rounded mb-4 space-y-3">
                  {chatHistory.length === 0 ? (
                    <div className="text-center text-slate-400">
                      <MessageSquare className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>Ask about FracTimeWave, FGT theory, Gravitonium parameters, temporal nodes, or research methodology</p>
                    </div>
                  ) : (
                    chatHistory.map((entry, index) => (
                      <div key={index} className={`flex ${entry.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-xs p-3 rounded-lg ${
                          entry.type === 'user' 
                            ? 'bg-purple-600 text-white' 
                            : 'bg-slate-700 text-slate-100'
                        }`}>
                          <p className="text-sm">{entry.message}</p>
                          <p className="text-xs opacity-70 mt-1">{entry.timestamp}</p>
                          {entry.note && (
                            <p className="text-xs text-yellow-300 mt-1">{entry.note}</p>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>

                {/* Chat Input */}
                <div className="flex space-x-2">
                  <Input
                    value={chatMessage}
                    onChange={(e) => setChatMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && sendChatMessage()}
                    placeholder="Ask about FracTimeWave theory, simulations, or temporal analysis..."
                    className="flex-1 bg-slate-700 border-slate-600 text-white"
                  />
                  <Button 
                    onClick={sendChatMessage}
                    disabled={isChatLoading || !chatMessage.trim()}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    {isChatLoading ? (
                      <MessageSquare className="w-4 h-4 animate-pulse" />
                    ) : (
                      <MessageSquare className="w-4 h-4" />
                    )}
                  </Button>
                </div>

                <div className="mt-4 p-3 bg-blue-900/20 rounded-lg">
                  <p className="text-xs text-blue-300">
                    💡 Currently using FAQ-based responses. Enhanced AI integration available with API key for advanced scientific discussions.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Research Monitoring Tab */}
          <TabsContent value="research" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Daily Research Entry */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white">
                    <Database className="w-5 h-5" />
                    <span>FracTimeWave Research Monitor</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-slate-300">Research Query</Label>
                    <Input
                      value={researchQuery}
                      onChange={(e) => setResearchQuery(e.target.value)}
                      className="bg-slate-700 border-slate-600 text-white"
                      placeholder="Enter today's FracTimeWave research focus..."
                    />
                  </div>

                  <Button 
                    onClick={submitResearchMonitoring}
                    disabled={isResearchLoading || !researchQuery.trim()}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    {isResearchLoading ? (
                      <>
                        <Database className="w-4 h-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Database className="w-4 h-4 mr-2" />
                        {getLanguageText('submit_research')}
                      </>
                    )}
                  </Button>

                  <div className="bg-slate-900/50 p-4 rounded">
                    <h4 className="text-white font-medium mb-2">Binary Encoding Process</h4>
                    <div className="text-xs text-slate-300 space-y-1">
                      <p>1. Query + Date → SHA-256 Hash</p>
                      <p>2. First 64 bits → Binary string</p>
                      <p>3. Count '1' bits → Hamming weight</p>
                      <p>4. Compare with yesterday → Hamming distance</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Research History */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white">
                    <History className="w-5 h-5" />
                    <span>Research Pattern History</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {researchHistory.map((entry, index) => (
                      <div key={index} className="bg-slate-700/50 p-3 rounded">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-medium text-white text-sm">{entry.research_query}</p>
                            <p className="text-xs text-slate-400">{entry.date}</p>
                          </div>
                          <div className="text-right">
                            <Badge variant="outline" className="text-xs mb-1">
                              H: {entry.hamming_weight}/64
                            </Badge>
                            {entry.hamming_distance > 0 && (
                              <Badge variant="secondary" className="text-xs">
                                Δ: {entry.hamming_distance}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="text-xs font-mono text-green-400 break-all">
                          {entry.binary_encoding}
                        </div>
                      </div>
                    ))}
                    {researchHistory.length === 0 && (
                      <p className="text-slate-400 text-center">No FracTimeWave research entries yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Enhanced Collaboration Tab */}
          <TabsContent value="collaboration" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white">
                    <Microscope className="w-5 h-5" />
                    <span>FracTimeWave Collaborations</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="bg-slate-700/50 p-4 rounded">
                      <h4 className="text-purple-400 mb-2">LSST Legacy Survey</h4>
                      <p className="text-sm text-slate-300 mb-2">
                        FracTimeWave integration for testing Gravitonium-enhanced fractal correlations 
                        with observational data validation.
                      </p>
                      <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                        <Mail className="w-4 h-4 mr-2" />
                        Contact LSST Team
                      </Button>
                    </div>

                    <div className="bg-slate-700/50 p-4 rounded">
                      <h4 className="text-blue-400 mb-2">LIGO Gravitational Waves</h4>
                      <p className="text-sm text-slate-300 mb-2">
                        FracTimeWave high-frequency detection proposal (~10⁶ Hz) with 
                        enhanced Gravitonium field sensitivity algorithms.
                      </p>
                      <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                        <Zap className="w-4 h-4 mr-2" />
                        Submit Proposal
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-white">
                    <Github className="w-5 h-5" />
                    <span>FracTimeWave Open Source</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Alert className="border-green-500 bg-green-500/10">
                    <Github className="w-4 h-4" />
                    <AlertDescription>
                      <strong>FracTimeWave v2.0.0 - MIT Licensed Scientific Application</strong>
                      <br />
                      Advanced features: Multi-language, Gravitonium optimization, 
                      Historical correlation, Research monitoring, AI assistant
                      <br />
                      Stack: Python FastAPI, React, MongoDB, SQLite
                    </AlertDescription>
                  </Alert>

                  <div className="space-y-3">
                    <div className="bg-slate-700/50 p-4 rounded">
                      <h4 className="text-yellow-400 mb-2">Open Source License</h4>
                      <p className="text-sm text-slate-300 mb-3">
                        FracTimeWave is licensed under MIT License (2025) by Danilo Madia. 
                        Free for research, education, and commercial applications.
                      </p>
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Github className="w-4 h-4 mr-2" />
                          View License
                        </Button>
                        <Button size="sm" variant="outline">
                          Documentation
                        </Button>
                      </div>
                    </div>
                  </div>

                  <Separator className="bg-slate-600" />
                  
                  <div className="text-center space-y-2">
                    <p className="text-sm text-slate-400">Scientific References</p>
                    <div className="flex justify-center space-x-4 text-xs">
                      <a href="https://doi.org/10.5281/zenodo.16734344" 
                         className="text-purple-400 hover:text-purple-300">
                        Zenodo 16734344
                      </a>
                      <a href="https://doi.org/10.5281/zenodo.16738046" 
                         className="text-blue-400 hover:text-blue-300">
                        Zenodo 16738046
                      </a>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      FracTimeWave v2.0.0 • MIT Licensed • Multi-Language
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Enhanced Footer */}
      <footer className="border-t border-slate-700/50 bg-slate-900/80 backdrop-blur-sm mt-12">
        <div className="container mx-auto px-6 py-6">
          <div className="text-center text-slate-400">
            <p className="text-sm">
              © 2025 FracTimeWave • Danilo Madia • 
              <span className="ml-2">Fractal Graviton Theory • MIT Licensed</span>
            </p>
            <p className="text-xs mt-2">
              Multi-Language • Gravitonium Enhanced • Research Monitoring • AI Assistant • Historical Correlation
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;