"""
FracTimeWave Full System Integration Tests

End-to-end tests that verify the complete system functionality
including frontend-backend integration, database operations,
and scientific accuracy across the entire application.
"""

import requests
import time
import json
import subprocess
import os
from datetime import datetime


class FracTimeWaveSystemTester:
    """Complete system integration tester for FracTimeWave."""
    
    def __init__(self):
        self.backend_url = "http://localhost:8001"
        self.frontend_url = "http://localhost:3000"
        self.test_results = []
        self.total_tests = 0
        self.passed_tests = 0
    
    def log_test(self, test_name: str, success: bool, message: str = ""):
        """Log test result."""
        self.total_tests += 1
        if success:
            self.passed_tests += 1
            status = "✅ PASS"
        else:
            status = "❌ FAIL"
        
        result = f"{status} - {test_name}"
        if message:
            result += f": {message}"
        
        print(result)
        self.test_results.append({
            "test": test_name,
            "success": success,
            "message": message
        })
    
    def test_system_health(self):
        """Test overall system health and accessibility."""
        print("\n🏥 Testing System Health...")
        
        # Test backend health
        try:
            response = requests.get(f"{self.backend_url}/api/health", timeout=10)
            backend_healthy = response.status_code == 200
            
            if backend_healthy:
                data = response.json()
                app_name = data.get("application", "")
                author = data.get("author", "")
                version = data.get("version", "")
                
                backend_msg = f"Application: {app_name}, Author: {author}, Version: {version}"
            else:
                backend_msg = f"HTTP {response.status_code}"
                
        except Exception as e:
            backend_healthy = False
            backend_msg = str(e)
        
        self.log_test("Backend Health Check", backend_healthy, backend_msg)
        
        # Test frontend accessibility
        try:
            response = requests.get(self.frontend_url, timeout=10)
            frontend_healthy = response.status_code == 200
            frontend_msg = f"HTTP {response.status_code}"
        except Exception as e:
            frontend_healthy = False
            frontend_msg = str(e)
        
        self.log_test("Frontend Accessibility", frontend_healthy, frontend_msg)
        
        return backend_healthy and frontend_healthy
    
    def test_scientific_core_functionality(self):
        """Test core scientific functionality end-to-end."""
        print("\n🔬 Testing Scientific Core Functionality...")
        
        # Test enhanced gravitational simulation
        try:
            simulation_params = {
                "r": 100.0,
                "time_steps": 1000,
                "time_max": 1e-6,
                "D_10f": 1.7,
                "amplitude_scale": 1e-5,
                "gravitonium_coupling": 1000.0,
                "gravitonium_mass_squared": 1e8
            }
            
            response = requests.post(
                f"{self.backend_url}/api/simulate-gravitational-waves-enhanced",
                json=simulation_params,
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                required_fields = ["simulation_id", "gravitonium_factor", "h_10_harmonic"]
                has_all_fields = all(field in data for field in required_fields)
                
                if has_all_fields:
                    sim_msg = f"H₁₀: {data['h_10_harmonic']:.2e}, G_factor: {data['gravitonium_factor']:.2e}"
                else:
                    has_all_fields = False
                    sim_msg = "Missing required fields in response"
            else:
                has_all_fields = False
                sim_msg = f"HTTP {response.status_code}"
                
        except Exception as e:
            has_all_fields = False
            sim_msg = str(e)
        
        self.log_test("Enhanced Gravitational Simulation", has_all_fields, sim_msg)
        
        # Test temporal node prediction for 2025-12-27
        try:
            node_params = {
                "date_string": "2025-12-27",
                "language": "en"
            }
            
            response = requests.post(
                f"{self.backend_url}/api/predict-temporal-node-enhanced",
                json=node_params,
                timeout=15
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get("success") and "node_analysis" in data:
                    node_analysis = data["node_analysis"]
                    is_temporal_node = node_analysis.get("is_temporal_node", False)
                    shannon_entropy = node_analysis.get("shannon_entropy", 0)
                    
                    if is_temporal_node and shannon_entropy > 0.69:
                        node_msg = f"Detected as temporal node, entropy: {shannon_entropy:.4f}"
                        node_success = True
                    else:
                        node_msg = f"Node detection failed: is_node={is_temporal_node}, entropy={shannon_entropy}"
                        node_success = False
                else:
                    node_success = False
                    node_msg = "Invalid response structure"
            else:
                node_success = False
                node_msg = f"HTTP {response.status_code}"
                
        except Exception as e:
            node_success = False
            node_msg = str(e)
        
        self.log_test("2025-12-27 Temporal Node Validation", node_success, node_msg)
        
        return has_all_fields and node_success
    
    def test_multi_language_functionality(self):
        """Test multi-language support across the system."""
        print("\n🌍 Testing Multi-Language Functionality...")
        
        languages_to_test = ["it", "en", "fr", "de", "es"]
        language_test_results = []
        
        for lang in languages_to_test:
            try:
                # Test health endpoint with language
                response = requests.get(f"{self.backend_url}/api/health?language={lang}", timeout=10)
                
                if response.status_code == 200:
                    data = response.json()
                    has_localized_content = "status" in data and "theory" in data
                    lang_success = has_localized_content
                    lang_msg = f"Status: {data.get('status', 'N/A')}"
                else:
                    lang_success = False
                    lang_msg = f"HTTP {response.status_code}"
                    
            except Exception as e:
                lang_success = False
                lang_msg = str(e)
            
            language_test_results.append(lang_success)
            self.log_test(f"Language Support ({lang.upper()})", lang_success, lang_msg)
        
        # Test supported languages endpoint
        try:
            response = requests.get(f"{self.backend_url}/api/supported-languages", timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                supported_langs = data.get("supported_languages", [])
                has_seven_languages = len(supported_langs) == 7
                
                if has_seven_languages:
                    codes = [lang["code"] for lang in supported_langs]
                    lang_list_msg = f"Supported: {', '.join(codes)}"
                else:
                    lang_list_msg = f"Found {len(supported_langs)} languages, expected 7"
            else:
                has_seven_languages = False
                lang_list_msg = f"HTTP {response.status_code}"
                
        except Exception as e:
            has_seven_languages = False
            lang_list_msg = str(e)
        
        self.log_test("Supported Languages Count", has_seven_languages, lang_list_msg)
        
        # Overall multi-language success
        overall_lang_success = has_seven_languages and all(language_test_results)
        return overall_lang_success
    
    def test_database_integration(self):
        """Test database integration and persistence."""
        print("\n💾 Testing Database Integration...")
        
        # Test research monitoring (SQLite)
        try:
            research_params = {
                "research_query": f"Integration test query {datetime.now().isoformat()}"
            }
            
            response = requests.post(
                f"{self.backend_url}/api/daily-research-monitoring",
                json=research_params,
                timeout=15
            )
            
            if response.status_code == 200:
                data = response.json()
                required_fields = ["binary_encoding", "hamming_weight", "status"]
                has_research_fields = all(field in data for field in required_fields)
                
                if has_research_fields:
                    research_msg = f"Encoded to {len(data['binary_encoding'])}-bit, Hamming: {data['hamming_weight']}"
                else:
                    research_msg = "Missing required fields"
            else:
                has_research_fields = False
                research_msg = f"HTTP {response.status_code}"
                
        except Exception as e:
            has_research_fields = False
            research_msg = str(e)
        
        self.log_test("Research Monitoring (SQLite)", has_research_fields, research_msg)
        
        # Test research history retrieval
        try:
            response = requests.get(f"{self.backend_url}/api/daily-research-history?days=30", timeout=15)
            
            if response.status_code == 200:
                data = response.json()
                has_history = "history" in data and "total_entries" in data
                
                if has_history:
                    total_entries = data["total_entries"]
                    history_msg = f"Retrieved {total_entries} research entries"
                else:
                    history_msg = "Missing history fields"
            else:
                has_history = False
                history_msg = f"HTTP {response.status_code}"
                
        except Exception as e:
            has_history = False
            history_msg = str(e)
        
        self.log_test("Research History Retrieval", has_history, history_msg)
        
        # Test MongoDB operations (through simulation storage)
        try:
            response = requests.get(f"{self.backend_url}/api/recent-simulations?limit=5", timeout=15)
            
            if response.status_code == 200:
                data = response.json()
                has_simulations_data = "simulations" in data
                mongo_msg = f"MongoDB accessible, simulations endpoint working"
            else:
                has_simulations_data = False
                mongo_msg = f"HTTP {response.status_code}"
                
        except Exception as e:
            has_simulations_data = False
            mongo_msg = str(e)
        
        self.log_test("MongoDB Integration", has_simulations_data, mongo_msg)
        
        return has_research_fields and has_history and has_simulations_data
    
    def test_interactive_features(self):
        """Test interactive features like chatbox and real-time updates."""
        print("\n💬 Testing Interactive Features...")
        
        # Test FAQ chatbox
        try:
            chat_params = {
                "message": "What is FracTimeWave?",
                "language": "en"
            }
            
            response = requests.post(
                f"{self.backend_url}/api/faq-chatbox",
                json=chat_params,
                timeout=15
            )
            
            if response.status_code == 200:
                data = response.json()
                has_chat_response = "response" in data and len(data["response"]) > 0
                
                if has_chat_response and "FracTimeWave" in data["response"]:
                    chat_msg = f"Response length: {len(data['response'])} chars"
                else:
                    has_chat_response = False
                    chat_msg = "Response doesn't contain expected content"
            else:
                has_chat_response = False
                chat_msg = f"HTTP {response.status_code}"
                
        except Exception as e:
            has_chat_response = False
            chat_msg = str(e)
        
        self.log_test("FAQ ChatBox Functionality", has_chat_response, chat_msg)
        
        # Test historical events correlation
        try:
            event_params = {
                "date": "2025-12-27",
                "language": "en"
            }
            
            response = requests.post(
                f"{self.backend_url}/api/historical-events",
                json=event_params,
                timeout=15
            )
            
            if response.status_code == 200:
                data = response.json()
                has_events_data = "events" in data and "language" in data
                
                if has_events_data:
                    events_count = len(data["events"])
                    events_msg = f"Found {events_count} historical events"
                else:
                    events_msg = "Missing events data structure"
            else:
                has_events_data = False
                events_msg = f"HTTP {response.status_code}"
                
        except Exception as e:
            has_events_data = False
            events_msg = str(e)
        
        self.log_test("Historical Events Correlation", has_events_data, events_msg)
        
        return has_chat_response and has_events_data
    
    def test_performance_benchmarks(self):
        """Test system performance under normal load."""
        print("\n⚡ Testing Performance Benchmarks...")
        
        # Test API response times
        try:
            start_time = time.time()
            response = requests.get(f"{self.backend_url}/api/health", timeout=10)
            health_response_time = time.time() - start_time
            
            health_performance_ok = response.status_code == 200 and health_response_time < 1.0
            health_perf_msg = f"Response time: {health_response_time:.3f}s"
            
        except Exception as e:
            health_performance_ok = False
            health_perf_msg = str(e)
        
        self.log_test("API Response Time", health_performance_ok, health_perf_msg)
        
        # Test simulation performance
        try:
            simulation_params = {
                "r": 100.0,
                "time_steps": 500,  # Moderate size for performance test
                "time_max": 1e-6,
                "D_10f": 1.7
            }
            
            start_time = time.time()
            response = requests.post(
                f"{self.backend_url}/api/simulate-gravitational-waves-enhanced",
                json=simulation_params,
                timeout=30
            )
            simulation_response_time = time.time() - start_time
            
            simulation_performance_ok = response.status_code == 200 and simulation_response_time < 10.0
            sim_perf_msg = f"Simulation time: {simulation_response_time:.3f}s"
            
        except Exception as e:
            simulation_performance_ok = False
            sim_perf_msg = str(e)
        
        self.log_test("Simulation Performance", simulation_performance_ok, sim_perf_msg)
        
        return health_performance_ok and simulation_performance_ok
    
    def test_scientific_accuracy_validation(self):
        """Validate scientific accuracy across the entire system."""
        print("\n🎯 Testing Scientific Accuracy Validation...")
        
        # Test fractal dimension consistency
        try:
            response = requests.get(f"{self.backend_url}/api/fractal-statistics/100?language=en", timeout=15)
            
            if response.status_code == 200:
                data = response.json()
                fractal_dimension = data.get("fractal_dimension", 0)
                fractal_accuracy_ok = abs(fractal_dimension - 1.7) < 1e-10
                
                if fractal_accuracy_ok:
                    fractal_msg = f"D₁₀,f = {fractal_dimension} (correct)"
                else:
                    fractal_msg = f"D₁₀,f = {fractal_dimension} (should be 1.7)"
            else:
                fractal_accuracy_ok = False
                fractal_msg = f"HTTP {response.status_code}"
                
        except Exception as e:
            fractal_accuracy_ok = False
            fractal_msg = str(e)
        
        self.log_test("Fractal Dimension Accuracy", fractal_accuracy_ok, fractal_msg)
        
        # Test known temporal nodes validation
        try:
            response = requests.get(f"{self.backend_url}/api/known-temporal-nodes?language=en", timeout=15)
            
            if response.status_code == 200:
                data = response.json()
                nodes = data.get("known_nodes", [])
                
                # Find 2025-12-27 node
                target_node = None
                for node in nodes:
                    if node["date"] == "2025-12-27":
                        target_node = node
                        break
                
                if target_node and target_node.get("analysis", {}).get("is_temporal_node", False):
                    nodes_accuracy_ok = True
                    nodes_msg = f"2025-12-27 correctly identified as temporal node"
                else:
                    nodes_accuracy_ok = False
                    nodes_msg = "2025-12-27 not properly identified as temporal node"
            else:
                nodes_accuracy_ok = False
                nodes_msg = f"HTTP {response.status_code}"
                
        except Exception as e:
            nodes_accuracy_ok = False
            nodes_msg = str(e)
        
        self.log_test("Known Temporal Nodes Accuracy", nodes_accuracy_ok, nodes_msg)
        
        return fractal_accuracy_ok and nodes_accuracy_ok
    
    def run_full_system_test(self):
        """Run complete system integration test suite."""
        print("🌊 FracTimeWave Full System Integration Test")
        print("=" * 50)
        
        start_time = time.time()
        
        # Run all test categories
        system_health = self.test_system_health()
        scientific_core = self.test_scientific_core_functionality()
        multi_language = self.test_multi_language_functionality()
        database_integration = self.test_database_integration()
        interactive_features = self.test_interactive_features()
        performance = self.test_performance_benchmarks()
        scientific_accuracy = self.test_scientific_accuracy_validation()
        
        end_time = time.time()
        total_time = end_time - start_time
        
        # Calculate overall results
        overall_success = all([
            system_health,
            scientific_core,
            multi_language,
            database_integration,
            interactive_features,
            performance,
            scientific_accuracy
        ])
        
        # Print summary
        print(f"\n📊 Integration Test Summary")
        print("=" * 50)
        print(f"Total Tests: {self.total_tests}")
        print(f"Passed: {self.passed_tests}")
        print(f"Failed: {self.total_tests - self.passed_tests}")
        print(f"Success Rate: {(self.passed_tests/self.total_tests)*100:.1f}%")
        print(f"Total Time: {total_time:.2f} seconds")
        
        if overall_success:
            print("\n🎉 ALL INTEGRATION TESTS PASSED!")
            print("FracTimeWave system is fully operational and ready for production.")
        else:
            print("\n⚠️  SOME INTEGRATION TESTS FAILED")
            print("Please review failed tests and fix issues before deployment.")
        
        print("\n📋 Detailed Results:")
        for result in self.test_results:
            status = "✅" if result["success"] else "❌"
            print(f"{status} {result['test']}: {result['message']}")
        
        return overall_success


if __name__ == "__main__":
    tester = FracTimeWaveSystemTester()
    success = tester.run_full_system_test()
    
    # Exit with appropriate code for CI/CD
    exit(0 if success else 1)